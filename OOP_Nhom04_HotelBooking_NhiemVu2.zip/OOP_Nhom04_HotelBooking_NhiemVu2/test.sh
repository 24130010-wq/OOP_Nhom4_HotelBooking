#!/bin/sh
set -eu
cd "$(dirname "$0")"
sh build.sh
mkdir -p build/test-classes
find test -name '*.java' > build/test-sources.txt
javac --release 11 -encoding UTF-8 -cp build/classes -d build/test-classes @build/test-sources.txt
java -cp build/classes:build/test-classes hotel.service.DemoBooking > build/member1-test-results.txt
cat build/member1-test-results.txt
if ! grep -q '^That bai: 0$' build/member1-test-results.txt; then
    echo 'Kiem thu nghiep vu thanh vien 1 chua dat'
    exit 1
fi
java -cp build/classes:build/test-classes vn.edu.ptit.oop.nhom04.ServiceIntegrationTest
java -Djava.awt.headless=true -cp build/classes:build/test-classes vn.edu.ptit.oop.nhom04.DialogIntegrationTest
java -Djava.awt.headless=true -cp build/classes:build/test-classes vn.edu.ptit.oop.nhom04.GuiSmokeTest
if [ "${1:-}" = "--gui" ]; then
    java -cp build/classes:build/test-classes vn.edu.ptit.oop.nhom04.GuiSmokeTest
    java -cp build/classes:build/test-classes vn.edu.ptit.oop.nhom04.DialogIntegrationTest
fi
