#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p build/classes dist
find src -name '*.java' > build/sources.txt
javac --release 11 -encoding UTF-8 -d build/classes @build/sources.txt
cp -R src/resources build/classes/
jar cfe dist/HotelBooking-NhiemVu2.jar vn.edu.ptit.oop.nhom04.Main -C build/classes .
echo 'Da tao dist/HotelBooking-NhiemVu2.jar'
