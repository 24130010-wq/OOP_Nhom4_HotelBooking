package vn.edu.ptit.oop.nhom04;

import hotel.model.*;
import hotel.service.*;
import model.Invoice;
import model.ServiceCharge;
import view.BookingDialog;
import view.InvoiceDialog;
import vn.edu.ptit.oop.nhom04.integration.*;
import vn.edu.ptit.oop.nhom04.ui.MainWindow;
import vn.edu.ptit.oop.nhom04.ui.panels.RoomMapPanel;
import vn.edu.ptit.oop.nhom04.util.DisplayFormats;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.math.BigDecimal;
import java.time.*;
import java.util.*;
import java.util.function.Consumer;

public final class DialogIntegrationTest {
    public static void main(String[] args) throws Exception {
        BookingService service=HotelApplication.createService(false);
        Booking booking=service.bookRoom("101",new Guest("TEST","Khách test","0900000000",""),LocalDate.now(),LocalDate.now().plusDays(3));
        CheckoutService checkout=new CheckoutService(service);
        Invoice invoice=new Invoice(booking,Arrays.asList(new ServiceCharge("Minibar",new BigDecimal("150000")),new ServiceCharge("Giặt ủi",new BigDecimal("100000"))));
        check(invoice.getTotal().compareTo(new BigDecimal("1750000"))==0,"Tiền và phụ phí chính xác");
        check(booking.getStatus()==BookingStatus.CONFIRMED,"Tạo hóa đơn không check-out");
        checkout.confirm(invoice);
        check(checkout.getInvoices().size()==1 && booking.getStatus()==BookingStatus.CHECKED_OUT,"Xác nhận lưu hóa đơn và trả phòng");
        try { checkout.confirm(invoice); throw new AssertionError("Không thanh toán hai lần"); }
        catch (IllegalStateException expected) { check(checkout.getInvoices().size()==1,"Không lưu trùng hóa đơn"); }
        System.out.println("PASS: invoice amounts, checkout confirmation, duplicate payment guard");
        if (!GraphicsEnvironment.isHeadless()) SwingUtilities.invokeAndWait(DialogIntegrationTest::testDialogs);
    }

    private static void testDialogs() {
        Main.configureUi();
        BookingService service=HotelApplication.createService(false);
        IntegratedHotelActions actions=new IntegratedHotelActions(service);
        MainWindow main=new MainWindow(new ServiceHotelGateway(service),actions);
        try {
            main.setVisible(true); main.validate();
            RoomMapPanel map=(RoomMapPanel)findType(main,RoomMapPanel.class);
            Rectangle r=map.getRoomBounds("101");
            map.dispatchEvent(new MouseEvent(map,MouseEvent.MOUSE_CLICKED,0,0,r.x+5,r.y+5,1,false,MouseEvent.BUTTON1));
            JButton book=(JButton)find(main,"bookingButton");
            JTable table=(JTable)find(main,"bookingTable");
            modal(book::doClick,dialog -> {
                check(dialog instanceof BookingDialog,"Phải mở form thật");
                fillBooking(dialog);
                ((JTextField)find(dialog,"phoneField")).setText("123");
                ((JButton)find(dialog,"confirmBookingButton")).doClick();
                check(dialog.isShowing() && !((JLabel)find(dialog,"bookingErrorLabel")).getText().isBlank(),"Lỗi điện thoại giữ form mở");
                ((JTextField)find(dialog,"phoneField")).setText("0912345678");
                snapshot(dialog,"docs/dat-phong.png");
                ((JButton)find(dialog,"confirmBookingButton")).doClick();
            });
            check(service.getAllBookings().size()==1 && table.getRowCount()==1,"Lưu từ form cập nhật bảng thật");
            check(map.roomAt(new Point(r.x+5,r.y+5)).getStatus()==vn.edu.ptit.oop.nhom04.integration.RoomStatus.OCCUPIED,"Lưu từ form cập nhật màu");
            modal(book::doClick,dialog -> {
                fillBooking(dialog); ((JButton)find(dialog,"confirmBookingButton")).doClick();
                check(dialog.isShowing() && !((JLabel)find(dialog,"bookingErrorLabel")).getText().isBlank(),"Trùng lịch hiện lỗi trên form");
                ((JButton)find(dialog,"cancelBookingButton")).doClick();
            });
            check(service.getAllBookings().size()==1,"Trùng lịch không thêm đơn");
            modal(book::doClick,dialog -> ((JButton)find(dialog,"cancelBookingButton")).doClick());
            check(service.getAllBookings().size()==1,"Hủy form không thêm đơn");
            table.setRowSelectionInterval(0,0);
            JButton out=(JButton)find(main,"checkoutButton");
            modal(out::doClick,dialog -> ((JButton)find(dialog,"cancelInvoiceButton")).doClick());
            check(service.getAllBookings().get(0).getStatus()==BookingStatus.CONFIRMED,"Đóng hóa đơn không trả phòng");
            check(actions.getCheckoutService().getInvoices().isEmpty(),"Đóng hóa đơn không lưu tiền");
            modal(out::doClick,dialog -> {
                check(dialog instanceof InvoiceDialog,"Mở hóa đơn thật");
                ((JCheckBox)find(dialog,"minibarCheckbox")).doClick();
                ((JCheckBox)find(dialog,"laundryCheckbox")).doClick();
                ((JButton)find(dialog,"calculateInvoiceButton")).doClick();
                String first=((JTextArea)find(dialog,"invoiceText")).getText();
                ((JButton)find(dialog,"calculateInvoiceButton")).doClick();
                check(first.equals(((JTextArea)find(dialog,"invoiceText")).getText()),"Tính lại không cộng phụ phí hai lần");
                check(first.contains(DisplayFormats.money(new BigDecimal("1750000"))),"Hiển thị tổng 1.750.000");
                snapshot(dialog,"docs/hoa-don.png");
                ((JButton)find(dialog,"confirmCheckoutButton")).doClick();
            });
            check(service.getAllBookings().get(0).getStatus()==BookingStatus.CHECKED_OUT,"Nút xác nhận gọi check-out thật");
            check(actions.getCheckoutService().getInvoices().size()==1,"Lưu hóa đơn đã thanh toán");
            check(!out.isEnabled(),"Không trả phòng lại");
            check(map.roomAt(new Point(r.x+5,r.y+5)).getStatus()==vn.edu.ptit.oop.nhom04.integration.RoomStatus.AVAILABLE,"Trả phòng cập nhật sơ đồ");
            snapshot(main,"docs/giao-dien.png");
            System.out.println("PASS: actual modal dialogs -> booking -> duplicate/cancel -> invoice preview/recalculate/cancel -> confirmed checkout -> UI refresh");
        } finally { main.dispose(); }
    }
    private static void fillBooking(JDialog dialog) {
        ((JTextField)find(dialog,"guestNameField")).setText("Nguyễn Khách Kiểm Thử");
        ((JTextField)find(dialog,"phoneField")).setText("0912345678");
        Date end=Date.from(LocalDate.now().plusDays(3).atStartOfDay(ZoneId.systemDefault()).toInstant());
        ((JSpinner)find(dialog,"checkOutSpinner")).setValue(end);
        check(((JComboBox<?>)find(dialog,"roomCombo")).getItemCount()==24,"Đủ 24 phòng từ service");
    }
    private static void modal(Runnable open,Consumer<JDialog> interact) {
        Throwable[] failure={null};
        javax.swing.Timer timer=new javax.swing.Timer(180,e -> {
            JDialog active=null;
            try {
                for (Window window:Window.getWindows()) if (window instanceof JDialog && window.isShowing()) active=(JDialog)window;
                if (active==null) throw new AssertionError("Chưa mở dialog");
                interact.accept(active);
            } catch (Throwable ex) { failure[0]=ex; }
            finally { if (active!=null && active.isShowing()) active.dispose(); }
        });
        timer.setRepeats(false); timer.start();
        try { open.run(); } finally { timer.stop(); }
        if (failure[0]!=null) throw new AssertionError("Kiểm tra dialog thất bại",failure[0]);
    }
    private static Component find(Container root,String name) {
        for (Component c:root.getComponents()) {
            if (name.equals(c.getName())) return c;
            if (c instanceof Container) { Component match=find((Container)c,name); if (match!=null) return match; }
        }
        return null;
    }
    private static Component findType(Container root,Class<?> type) {
        for (Component c:root.getComponents()) {
            if (type.isInstance(c)) return c;
            if (c instanceof Container) { Component match=findType((Container)c,type); if (match!=null) return match; }
        }
        return null;
    }
    private static void snapshot(Window window,String path) {
        JRootPane root=((RootPaneContainer)window).getRootPane();
        BufferedImage image=new BufferedImage(root.getWidth(),root.getHeight(),BufferedImage.TYPE_INT_RGB);
        Graphics2D g=image.createGraphics(); root.printAll(g); g.dispose();
        try { ImageIO.write(image,"png",new File(path)); }
        catch (java.io.IOException ex) { throw new IllegalStateException(ex); }
    }
    private static void check(boolean valid,String message) { if (!valid) throw new AssertionError(message); }
}
