package vn.edu.ptit.oop.nhom04;

import vn.edu.ptit.oop.nhom04.demo.DemoHotelGateway;
import vn.edu.ptit.oop.nhom04.integration.*;
import vn.edu.ptit.oop.nhom04.ui.MainWindow;
import vn.edu.ptit.oop.nhom04.ui.dialogs.AboutDialog;
import vn.edu.ptit.oop.nhom04.ui.panels.RoomMapPanel;
import vn.edu.ptit.oop.nhom04.ui.table.BookingTableModel;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

/** Không cần JUnit: kiểm tra chọn phòng, lọc, sort và truyền đúng đặt phòng sang check-out. */
public final class GuiSmokeTest {
    public static void main(String[] args) throws Exception {
        SwingUtilities.invokeAndWait(() -> {
            Main.configureUi();
            DemoHotelGateway gateway = new DemoHotelGateway();
            check(gateway.getRooms().size() == 24, "Phải có 24 phòng");
            RoomMapPanel map = new RoomMapPanel();
            map.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));
            map.setSize(790, 350);
            map.setRooms(gateway.getRooms());
            final String[] selected = {null};
            map.setOnRoomSelected(r -> selected[0] = r.getNumber());
            for (RoomView room : gateway.getRooms()) {
                Rectangle r = map.getRoomBounds(room.getNumber());
                Point center = new Point(r.x + r.width / 2, r.y + r.height / 2);
                check(map.roomAt(center).getNumber().equals(room.getNumber()), "Sai hit-test " + room.getNumber());
                map.dispatchEvent(new MouseEvent(map, MouseEvent.MOUSE_CLICKED, 0, 0, center.x, center.y, 1, false, MouseEvent.BUTTON1));
                check(room.getNumber().equals(selected[0]), "Sai callback click");
            }
            map.setFloorFilter(2);
            check(map.getRoomBounds("101") == null, "Phòng tầng khác phải ẩn");
            check(map.getRoomBounds("201") != null, "Phòng tầng 2 phải hiện");
            check(map.roomAt(new Point(2, 2)) == null, "Click vùng trống không được chọn phòng");
            map.setFloorFilter(0);
            map.setSize(950, 400);
            Rectangle resized = map.getRoomBounds("406");
            check(map.roomAt(new Point(resized.x + 5, resized.y + 5)).getNumber().equals("406"), "Hit-test sau resize");
            BufferedImage image = new BufferedImage(950, 400, BufferedImage.TYPE_INT_RGB);
            Graphics2D g = image.createGraphics();
            map.paint(g); g.dispose();

            BookingTableModel model = new BookingTableModel();
            model.setBookings(gateway.getBookings());
            check(model.getRowCount() == 6 && model.getColumnCount() == 8, "Bảng mẫu không đúng");
            check(model.getColumnClass(3) == LocalDate.class && model.getColumnClass(6) == BigDecimal.class, "Sai kiểu dữ liệu sort");
            check(!model.isCellEditable(0, 0), "Bảng phải chỉ đọc");
            if (!GraphicsEnvironment.isHeadless()) {
                testWindow(gateway);
                testIntegratedWindow();
            }
            System.out.println("PASS: 24 rooms, click/resize/filter, table types"
                    + (GraphicsEnvironment.isHeadless() ? " (headless)" : ", window, action routing, refresh, icons, About"));
        });
    }

    private static void testWindow(DemoHotelGateway gateway) {
        final String[] routed = {null};
        HotelActions actions = new HotelActions() {
            public void openBooking(JFrame owner, RoomView room, Runnable afterChange) { routed[0] = room.getNumber(); afterChange.run(); }
            public void openCheckout(JFrame owner, BookingView booking, Runnable afterChange) { routed[0] = booking.getId(); afterChange.run(); }
            public void openCharts(JFrame owner) { routed[0] = "charts"; }
        };
        MainWindow window = new MainWindow(gateway, actions);
        try {
            window.setVisible(true);
            window.validate();
            JTable table = (JTable) find(window, "bookingTable");
            JTextField search = (JTextField) find(window, "searchField");
            JButton checkout = (JButton) find(window, "checkoutButton");
            JButton book = (JButton) find(window, "bookingButton");
            check(!book.isEnabled() && !checkout.isEnabled(), "Không chọn gì thì nút phải tắt");
            check(book.getIcon() != null && book.getIcon().getIconWidth() == 16, "Thiếu icon PNG 16px");
            check(!window.getIconImages().isEmpty(), "Thiếu icon cửa sổ");
            table.getRowSorter().toggleSortOrder(2);
            table.getRowSorter().toggleSortOrder(2);
            int targetRow = -1;
            for (int row = 0; row < table.getRowCount(); row++) {
                if ("DP001".equals(table.getValueAt(row, 0))) targetRow = row;
            }
            check(targetRow >= 0, "Không tìm thấy đặt phòng đang ở");
            table.setRowSelectionInterval(targetRow, targetRow);
            String expectedId = table.getValueAt(targetRow, 0).toString();
            check(checkout.isEnabled(), "Đặt phòng đang ở phải cho check-out");
            checkout.doClick();
            check(expectedId.equals(routed[0]), "Phải convert view row sang model row khi sort");
            String expectedRoom = table.getValueAt(table.getSelectedRow(), 1).toString();
            book.doClick();
            check(expectedRoom.equals(routed[0]), "Đặt phòng phải dùng phòng đang chọn");
            search.setText("[");
            check(table.getRowCount() == 0, "Ký tự regex phải được hiểu là văn bản thường");
            check(!checkout.isEnabled(), "Lọc mất dòng không được check-out dòng cũ");
            search.setText("võ ngọc mai");
            check(table.getRowCount() == 1, "Tìm tiếng Việt không phân biệt hoa thường");
            table.setRowSelectionInterval(0, 0);
            check(!checkout.isEnabled(), "Không check-out đặt phòng tương lai");
            search.setText("DP006"); table.setRowSelectionInterval(0, 0);
            check(!checkout.isEnabled(), "Không check-out lại đặt phòng đã trả");
            search.setText("");
            RoomMapPanel map = (RoomMapPanel) findByClass(window, RoomMapPanel.class);
            Rectangle maintenance = map.getRoomBounds("206");
            map.dispatchEvent(new MouseEvent(map, MouseEvent.MOUSE_CLICKED, 0, 0,
                    maintenance.x + 5, maintenance.y + 5, 1, false, MouseEvent.BUTTON1));
            check(!book.isEnabled(), "Phòng bảo trì không được đặt");
            window.refreshData();
            check(!book.isEnabled(), "Refresh phải giữ đúng trạng thái phòng chọn");
            AboutDialog about = new AboutDialog(window);
            check(about.isModal() && about.getDefaultCloseOperation() == WindowConstants.DISPOSE_ON_CLOSE, "About dialog không đúng");
            about.dispose();
            BufferedImage preview = new BufferedImage(window.getRootPane().getWidth(), window.getRootPane().getHeight(), BufferedImage.TYPE_INT_RGB);
            Graphics2D graphics = preview.createGraphics();
            window.getRootPane().printAll(graphics); graphics.dispose();
            try {
                new File("docs").mkdirs();
                ImageIO.write(preview, "png", new File("docs/giao-dien-demo.png"));
            } catch (java.io.IOException ex) { throw new IllegalStateException(ex); }
        } finally { window.dispose(); }
    }

    private static void testIntegratedWindow() {
        hotel.service.BookingService service = HotelApplication.createService(true);
        ServiceHotelGateway gateway = new ServiceHotelGateway(service);
        String[] newId = {null};
        HotelActions realServiceActions = new HotelActions() {
            public void openBooking(JFrame owner, RoomView room, Runnable afterChange) {
                try {
                    hotel.model.Booking booking = service.bookRoom(room.getNumber(),
                            new hotel.model.Guest("GUI01", "Khách kiểm tra GUI", "0900000010", ""),
                            LocalDate.now(), LocalDate.now().plusDays(3));
                    newId[0] = booking.getBookingId();
                    afterChange.run();
                } catch (hotel.service.RoomNotAvailableException ex) { throw new AssertionError(ex); }
            }
            public void openCheckout(JFrame owner, BookingView booking, Runnable afterChange) {
                service.checkOut(booking.getId());
                afterChange.run();
            }
            public void openCharts(JFrame owner) { }
        };
        MainWindow window = new MainWindow(gateway, realServiceActions);
        try {
            window.setVisible(true);
            window.validate();
            JTable table = (JTable) find(window, "bookingTable");
            JButton book = (JButton) find(window, "bookingButton");
            JButton checkout = (JButton) find(window, "checkoutButton");
            RoomMapPanel map = (RoomMapPanel) findByClass(window, RoomMapPanel.class);
            check(table.getRowCount() == 4, "Bảng nhận đơn thật từ service");
            Rectangle room = map.getRoomBounds("101");
            map.dispatchEvent(new MouseEvent(map, MouseEvent.MOUSE_CLICKED, 0, 0,
                    room.x + 5, room.y + 5, 1, false, MouseEvent.BUTTON1));
            book.doClick();
            check(service.getAllBookings().size() == 5 && table.getRowCount() == 5, "Callback đặt thật cập nhật bảng");
            check(map.roomAt(new Point(room.x + 5, room.y + 5)).getStatus() == RoomStatus.OCCUPIED, "Callback đặt thật cập nhật màu phòng");
            table.getRowSorter().toggleSortOrder(2);
            for (int row = 0; row < table.getRowCount(); row++) {
                if (newId[0].equals(table.getValueAt(row, 0))) { table.setRowSelectionInterval(row, row); break; }
            }
            check(checkout.isEnabled(), "Có thể check-out đơn mới tạo");
            checkout.doClick();
            check(service.getAllBookings().stream().filter(b -> b.getBookingId().equals(newId[0]))
                    .findFirst().get().getStatus() == hotel.model.BookingStatus.CHECKED_OUT, "Đã gọi service check-out");
            check(!checkout.isEnabled(), "Sau callback check-out nút bị tắt");
            check(map.roomAt(new Point(room.x + 5, room.y + 5)).getStatus() == RoomStatus.AVAILABLE, "Callback trả thật cập nhật màu phòng");
            BufferedImage preview = new BufferedImage(window.getRootPane().getWidth(), window.getRootPane().getHeight(), BufferedImage.TYPE_INT_RGB);
            Graphics2D graphics = preview.createGraphics();
            window.getRootPane().printAll(graphics); graphics.dispose();
            try { ImageIO.write(preview, "png", new File("docs/giao-dien.png")); }
            catch (java.io.IOException ex) { throw new IllegalStateException(ex); }
            System.out.println("PASS: integrated window -> real booking/checkout service -> refresh table and room colors");
        } finally { window.dispose(); }
    }
    private static Component find(Container root, String name) {
        for (Component child : root.getComponents()) {
            if (name.equals(child.getName())) return child;
            if (child instanceof Container) {
                Component result = find((Container) child, name);
                if (result != null) return result;
            }
        }
        return null;
    }
    private static Component findByClass(Container root, Class<?> type) {
        for (Component child : root.getComponents()) {
            if (type.isInstance(child)) return child;
            if (child instanceof Container) {
                Component result = findByClass((Container) child, type);
                if (result != null) return result;
            }
        }
        return null;
    }
    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
