package vn.edu.ptit.oop.nhom04;

import hotel.model.Booking;
import hotel.model.Guest;
import hotel.repository.InMemoryBookingRepository;
import hotel.service.BookingService;
import hotel.service.RoomNotAvailableException;
import vn.edu.ptit.oop.nhom04.integration.*;
import java.math.BigDecimal;
import java.time.*;

/** Kiểm tra service thành viên 1 -> adapter -> dữ liệu giao diện. */
public final class ServiceIntegrationTest {
    public static void main(String[] args) throws Exception {
        BookingService service = new BookingService(new InMemoryBookingRepository());
        LocalDate today = LocalDate.now();
        ServiceHotelGateway gateway = new ServiceHotelGateway(service);
        Guest guest = new Guest("TEST01", "Khách kiểm thử", "0900000000", "");
        check(gateway.getRooms().size() == 24 && gateway.getBookings().isEmpty(), "Khởi tạo rỗng");
        check(room(gateway, "104").getPricePerNight().compareTo(new BigDecimal("800000")) == 0, "Giá Deluxe từ code thành viên 1");
        check(room(gateway, "103").getType().equals("Standard"), "Bố trí 3 Standard mỗi tầng");
        check(!room(gateway, "106").getAmenities().isEmpty(), "Tiện nghi đa hình");

        Booking booking = service.bookRoom("101", guest, today, today.plusDays(3));
        BookingView view = gateway.getBookings().get(0);
        check(view.getId().equals(booking.getBookingId()), "Mã thật từ repository");
        check(view.getGuestName().equals(guest.getFullName()) && view.getNights() == 3, "Khách và số đêm thật");
        check(view.getRoomTotal().compareTo(new BigDecimal("1500000")) == 0, "Tiền phòng thật");
        check(room(gateway, "101").getStatus() == RoomStatus.OCCUPIED, "Đặt hôm nay cập nhật trạng thái GUI");
        check(service.findRoom("101").get().getStatus() == hotel.model.RoomStatus.AVAILABLE, "Adapter không thay đổi model khi đọc");
        try {
            service.bookRoom("101", guest, today.plusDays(1), today.plusDays(4));
            throw new AssertionError("Phải từ chối đặt trùng");
        } catch (RoomNotAvailableException expected) {
            check(gateway.getBookings().size() == 1, "Thất bại không thêm dòng GUI");
        }
        service.bookRoom("102", guest, today.plusDays(4), today.plusDays(6));
        check(room(gateway, "102").getStatus() == RoomStatus.AVAILABLE, "Đặt tương lai không chiếm phòng hôm nay");
        service.checkOut(booking.getBookingId(), today);
        check(room(gateway, "101").getStatus() == RoomStatus.AVAILABLE, "Check-out hiện phòng trống");
        check(gateway.getBookings().get(0).isCheckedOut(), "Check-out cập nhật dòng bảng");
        service.bookRoom("101", guest, today, today.plusDays(2));
        check(room(gateway, "101").getStatus() == RoomStatus.OCCUPIED, "Đặt lại sau trả sớm");
        service.setRoomMaintenance("101");
        check(room(gateway, "101").getStatus() == RoomStatus.MAINTENANCE, "Bảo trì ưu tiên hiển thị");
        service.setRoomAvailable("101");
        check(room(gateway, "101").getStatus() == RoomStatus.OCCUPIED, "Bỏ bảo trì vẫn tính lịch đang ở");

        ServiceHotelGateway onCheckoutDay = new ServiceHotelGateway(service,
                Clock.fixed(today.plusDays(2).atStartOfDay(ZoneId.systemDefault()).toInstant(), ZoneId.systemDefault()));
        check(room(onCheckoutDay, "101").getStatus() == RoomStatus.AVAILABLE, "Khoảng ngày không gồm ngày trả");
        try {
            gateway.getBookings().clear();
            throw new AssertionError("Danh sách GUI phải chỉ đọc");
        } catch (UnsupportedOperationException expected) {
            check(service.getAllBookings().size() == 3, "Không xóa dữ liệu service qua GUI");
        }
        BookingService samples = HotelApplication.createService(true);
        ServiceHotelGateway sampleGateway = new ServiceHotelGateway(samples);
        check(samples.getAllBookings().size() == 4, "Dữ liệu mẫu tạo qua service");
        check(sampleGateway.getRooms().stream().filter(r -> r.getStatus() == RoomStatus.OCCUPIED).count() == 3, "3 phòng đang ở");
        check(sampleGateway.getRooms().stream().filter(r -> r.getStatus() == RoomStatus.MAINTENANCE).count() == 2, "2 phòng bảo trì");
        check(HotelApplication.createService(false).getAllBookings().isEmpty(), "Chế độ --empty");
        System.out.println("PASS: service -> repository -> gateway, dates/status, price, checkout, overlap, sample/empty");
    }
    private static RoomView room(ServiceHotelGateway gateway, String number) {
        return gateway.getRooms().stream().filter(r -> r.getNumber().equals(number)).findFirst().orElseThrow();
    }
    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
