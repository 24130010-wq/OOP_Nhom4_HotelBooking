# Đặt phòng Khách sạn - Bản ghép nghiệp vụ + giao diện + form/hóa đơn

Đã nối các phần trong cùng project Eclipse `OOP_Nhom04_HotelBooking_NhiemVu2`.
Tên thư mục project giữ nguyên để Eclipse đang dùng không bị mất liên kết.

## Chạy trong Eclipse

1. Chọn project → Refresh (F5). Nếu đang chạy bản cũ, đóng cửa sổ cũ.
2. Mở `src/vn/edu/ptit/oop/nhom04/Main.java` → Run As → Java Application.
3. Hoặc chuột phải `HotelBooking_Ghep_1_2_3.launch` → Run As.
4. Nếu gặp lỗi biên dịch cũ, chọn Project → Clean cho project này rồi chạy lại.
5. Dùng JDK 11 trở lên, khuyến nghị JDK 17. Encoding UTF-8.

Nếu chưa import: File → Import → Existing Projects into Workspace → chọn thư mục này.
Không cần import riêng project bạn gửi. Không cần thư viện ngoài cho bản hiện tại.

## Chạy bằng JAR

```sh
java -jar dist/HotelBooking-NhiemVu2.jar
```

Mặc định có 4 đơn minh họa được tạo qua BookingService thật: 3 đơn từ hôm nay, 1 đơn tương lai,
và 2 phòng bảo trì. Tên/số điện thoại là dữ liệu giả. Chạy rỗng để tự demo từ đầu:

```sh
java -jar dist/HotelBooking-NhiemVu2.jar --empty
```

macOS/Linux có thể dùng `sh run.sh`; Windows dùng `run.bat` (cần JDK trong PATH).
Script Windows chưa được kiểm tra trên máy Windows. Dữ liệu đơn và hóa đơn chỉ lưu trong bộ nhớ,
đóng ứng dụng sẽ mất; không có file/DB trong bản này.

## Kịch bản demo đã hoạt động

1. Click phòng 101 trên sơ đồ → Đặt phòng.
2. Điền họ tên, điện thoại 10 chữ số, ngày nhận hôm nay, ngày trả sau 3 ngày.
3. Chọn Đặt phòng: lưu qua service, đóng form, bảng có dòng mới, phòng đổi màu Đang ở.
4. Thử đặt lại cùng phòng và khoảng ngày: form báo lỗi trùng, không thêm đơn.
5. Chọn dòng đơn vừa tạo trong bảng → Check-out.
6. Chọn Minibar và Giặt ủi → xem tổng tiền. Tiền phòng 1.500.000đ + 250.000đ = 1.750.000đ.
7. Bấm Xác nhận thanh toán & trả phòng: lưu hóa đơn vào bộ nhớ, gọi check-out,
   bảng chuyển Đã trả phòng, sơ đồ trở lại Trống.

Đóng form đặt phòng không tạo đơn. Đóng hoặc chỉ tính thử hóa đơn không trả phòng.
Tính hóa đơn nhiều lần không cộng phụ phí lặp. Xác nhận chỉ thực hiện một lần.
Tiền phòng tính theo số đêm đã đặt (quy tắc gốc của Booking), chưa giảm tiền khi trả sớm.
Trạng thái theo lịch, chưa có quy trình check-in thực tế hoặc xử lý ở quá ngày dự kiến.

## Đã ghép và điều chỉnh

- Giữ model/service `hotel.*` từ bộ thành viên 1 gửi trước: Room, Guest, Booking, BookingService.
- Giữ cửa sổ, sơ đồ 24 phòng, bảng, menu, toolbar, About của nhiệm vụ 2.
- Nhận các file BookingDialog, InvoiceDialog, Invoice, ServiceCharge từ thư mục `HotelBooking (1)`.
- Giữ ý tưởng bố cục form navy/teal và phụ phí minibar/giặt ủi; điều chỉnh lớp để nối nghiệp vụ.
- Form không còn danh sách 13 hạng phòng và giá cố định riêng. Nó dùng đúng 24 phòng từ service:
  mỗi tầng 3 Standard 500.000đ, 2 Deluxe 800.000đ, 1 Suite 1.500.000đ/đêm.
- Đặt phòng gọi `service.bookRoom(...)`; không mở hóa đơn ngay lúc đặt.
- Check-out mở hóa đơn từ Booking thật; chỉ nút xác nhận gọi `service.checkOut(...)`.
- Các khoản tiền dùng BigDecimal thống nhất, không ép về int hoặc dùng double.
- Hóa đơn là bản chụp bất biến; mỗi lần tính dựng lại danh sách phụ phí được chọn.
- Gateway tính trạng thái phòng hôm nay từ lịch đặt và trạng thái bảo trì, không sửa model khi đọc.
- Chưa làm biểu đồ JFreeChart: nút Biểu đồ thông báo chờ phần thành viên 4.

## Luồng code và điểm ghép tiếp

```text
Main
  -> HotelApplication -> một BookingService + một InMemoryBookingRepository
  -> ServiceHotelGateway -> MainWindow / RoomMapPanel / BookingTableModel
  -> IntegratedHotelActions
       -> view.BookingDialog -> BookingService.bookRoom -> refreshData
       -> view.InvoiceDialog -> CheckoutService.confirm -> BookingService.checkOut -> refreshData
```

`CheckoutService.getInvoices()` trả các hóa đơn đã thanh toán trong bộ nhớ.
Khi ghép biểu đồ, dùng `IntegratedHotelActions.getCheckoutService()` và cùng BookingService.
Không tạo một service/repository khác trong cửa sổ biểu đồ. Biểu đồ mở riêng dùng DISPOSE_ON_CLOSE.
Tác vụ I/O lâu dùng SwingWorker; callback cập nhật GUI chạy trên EDT.

`PendingHotelActions` và thư mục `demo/` là code tham khảo trước đây; Main hiện dùng
IntegratedHotelActions và ServiceHotelGateway, không dùng các lớp giữ chỗ đó nữa.
`HotelBooking_Ghep_1_2.launch` cũ vẫn chạy cùng Main nhưng nên dùng launch 1_2_3 mới.

## Các lớp cần hiểu

| File | Vai trò |
|---|---|
| `Main.java` | Khởi chạy và nối service/giao diện |
| `HotelApplication.java` | Repository và dữ liệu minh họa |
| `hotel/service/BookingService.java` | Đặt phòng, lịch trùng, trả phòng |
| `hotel/service/CheckoutService.java` | Chốt hóa đơn sau check-out thành công |
| `integration/IntegratedHotelActions.java` | Nối nút giao diện với hai dialog |
| `integration/ServiceHotelGateway.java` | Chuyển dữ liệu thật sang GUI |
| `ui/MainWindow.java` | Cửa sổ chính, chọn dòng, làm mới |
| `view/BookingDialog.java` | Nhập liệu, cập nhật số đêm và tiền, gọi service |
| `view/InvoiceDialog.java` | Xem trước, phụ phí và xác nhận |
| `model/Invoice.java`, `model/ServiceCharge.java` | Tính và lưu ảnh chụp hóa đơn |

Package đang có `hotel.*`, `view.*`, `model.*`, `vn.edu.ptit.oop.nhom04.*` để ghép các nguồn.
Trước khi nộp nên thống nhất theo package gốc của môn và số nhóm thật.
Guest hiện chưa có trường CCCD riêng; cần nhóm bổ sung theo đề. Không tuyên bố bản này hoàn thành cả đề 4.

## Kiểm tra

```sh
sh test.sh
sh test.sh --gui
```

- Bộ 18 test nghiệp vụ gốc của bạn 1.
- Adapter: giá, trạng thái hôm nay/tương lai, trùng lịch, bảo trì, trả sớm.
- GUI chính: chọn 24 phòng, resize, lọc, sort, tìm tiếng Việt, icon và About.
- Hóa đơn: tổng tiền/phụ phí, chốt một lần và lưu sau check-out thành công.
- Form thật: nhập sai điện thoại, đặt thành công, đặt trùng, hủy form,
  đóng hóa đơn không check-out, tính nhiều lần không cộng lặp,
  xác nhận thật cập nhật bảng và màu phòng.
- Ảnh chạy thử nằm ở `docs/dat-phong.png`, `docs/hoa-don.png`, `docs/giao-dien.png`.

## Sao lưu và nguồn

Đã tạo ZIP sao lưu `HotelBooking_TruocKhiGhepForm_*` bên cạnh project trước khi sửa.
Nguồn gốc bên ngoài trong Documents/HotelBooking và Documents/HotelBooking (1) không bị sửa.
Các file form gốc được giữ trong `docs/received-form-original/` để nhóm đối chiếu.
DemoBooking kiểm thử nằm trong test, MainTest mở form riêng không được đưa làm điểm chạy chính.
Đọc hiểu phần code mình trình bày và ghi việc dùng AI vào nhật ký theo hướng dẫn môn học.
