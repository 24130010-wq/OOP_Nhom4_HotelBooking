package hotel.service;

import model.Invoice;
import java.util.*;

/** Chốt hóa đơn và lưu trong bộ nhớ sau khi check-out thành công. */
public final class CheckoutService {
    private final BookingService bookings;
    private final Map<String,Invoice> invoices=new LinkedHashMap<>();
    public CheckoutService(BookingService bookings) { this.bookings=Objects.requireNonNull(bookings); }
    public void confirm(Invoice invoice) {
        Objects.requireNonNull(invoice);
        if (invoices.containsKey(invoice.getBookingId())) throw new IllegalStateException("Đơn đã được thanh toán.");
        bookings.checkOut(invoice.getBookingId());
        invoices.put(invoice.getBookingId(),invoice);
    }
    public List<Invoice> getInvoices() { return List.copyOf(invoices.values()); }
}
