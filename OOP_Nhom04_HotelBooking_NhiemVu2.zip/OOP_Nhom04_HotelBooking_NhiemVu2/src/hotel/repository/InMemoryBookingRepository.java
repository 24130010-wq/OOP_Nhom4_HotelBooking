package hotel.repository;

import hotel.model.Booking;
import java.util.*;

/** Kho dùng chung cho service và giao diện. Dữ liệu chỉ tồn tại trong lần chạy hiện tại. */
public final class InMemoryBookingRepository implements BookingRepository {
    private final Map<String, Booking> bookings = new LinkedHashMap<>();

    @Override public void add(Booking booking) {
        Objects.requireNonNull(booking, "Đặt phòng không được null");
        if (bookings.containsKey(booking.getBookingId())) {
            throw new IllegalArgumentException("Mã đặt phòng đã tồn tại");
        }
        bookings.put(booking.getBookingId(), booking);
    }
    @Override public void update(Booking booking) {
        Objects.requireNonNull(booking, "Đặt phòng không được null");
        if (!bookings.containsKey(booking.getBookingId())) {
            throw new IllegalArgumentException("Không tìm thấy đặt phòng để cập nhật");
        }
        bookings.put(booking.getBookingId(), booking);
    }
    @Override public Optional<Booking> findById(String bookingId) {
        return Optional.ofNullable(bookings.get(bookingId));
    }
    @Override public List<Booking> findAll() {
        return Collections.unmodifiableList(new ArrayList<>(bookings.values()));
    }
}
