package hotel.model;

import java.math.BigDecimal;
import java.util.Objects;

public abstract class Room {
    private final String roomNumber;
    private final int floor;
    private RoomStatus status;

    public Room(String roomNumber, int floor, RoomStatus status) {
        if (roomNumber == null || roomNumber.isBlank()) {
            throw new IllegalArgumentException("Ma phong khong duoc de trong.");
        }

        if (floor < 1 || floor > 4) {
            throw new IllegalArgumentException("Tang phai tu 1 den 4.");
        }

        this.roomNumber = roomNumber;
        this.floor = floor;
        this.status = Objects.requireNonNull(status);
    }

    public abstract String getRoomType();

    public abstract BigDecimal getPricePerNight();

    // Bổ sung khi ghép GUI theo yêu cầu đề 4; từng loại phòng tự mô tả tiện nghi.
    public abstract String getAmenities();

    public String getRoomNumber() {
        return roomNumber;
    }

    public int getFloor() {
        return floor;
    }

    public RoomStatus getStatus() {
        return status;
    }

    public void setStatus(RoomStatus status) {
        this.status = Objects.requireNonNull(status);
    }
}
