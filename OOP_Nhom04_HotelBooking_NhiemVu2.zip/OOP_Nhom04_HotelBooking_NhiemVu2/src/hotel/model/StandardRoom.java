package hotel.model;

import java.math.BigDecimal;

public class StandardRoom extends Room {

    public StandardRoom(String roomNumber, int floor) {
        super(roomNumber, floor, RoomStatus.AVAILABLE);
    }

    @Override
    public String getRoomType() {
        return "Standard";
    }

    @Override
    public BigDecimal getPricePerNight() {
        return new BigDecimal("500000");
    }

    @Override
    public String getAmenities() {
        return "Điều hòa, Wi-Fi, TV, giường đôi";
    }
}
