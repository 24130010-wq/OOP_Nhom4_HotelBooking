package hotel.model;

import java.math.BigDecimal;

public class DeluxeRoom extends Room {

    public DeluxeRoom(String roomNumber, int floor) {
        super(roomNumber, floor, RoomStatus.AVAILABLE);
    }

    @Override
    public String getRoomType() {
        return "Deluxe";
    }

    @Override
    public BigDecimal getPricePerNight() {
        return new BigDecimal("800000");
    }

    @Override
    public String getAmenities() {
        return "Điều hòa, Wi-Fi, TV, minibar, bàn làm việc";
    }
}
