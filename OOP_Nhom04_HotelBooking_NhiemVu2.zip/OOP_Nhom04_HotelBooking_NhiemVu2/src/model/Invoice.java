package model;

import hotel.model.Booking;
import java.math.BigDecimal;
import java.util.*;
import vn.edu.ptit.oop.nhom04.util.DisplayFormats;

/** Ảnh chụp hóa đơn: tính lại không cộng phụ phí nhiều lần, không làm đổi Booking. */
public final class Invoice {
    private final String bookingId, guestName, phone, room;
    private final long nights;
    private final BigDecimal roomFee;
    private final List<ServiceCharge> charges;

    public Invoice(Booking booking, List<ServiceCharge> charges) {
        Objects.requireNonNull(booking);
        bookingId = booking.getBookingId();
        guestName = booking.getGuest().getFullName();
        phone = booking.getGuest().getPhone();
        room = booking.getRoomNumber() + " - " + booking.getRoom().getRoomType();
        nights = booking.getNumberOfNights();
        roomFee = booking.getRoomTotal();
        this.charges = List.copyOf(charges);
    }
    public String getBookingId() { return bookingId; }
    public BigDecimal getRoomFee() { return roomFee; }
    public List<ServiceCharge> getCharges() { return charges; }
    public BigDecimal getTotalCharges() {
        return charges.stream().map(ServiceCharge::getAmount).reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    public BigDecimal getTotal() { return roomFee.add(getTotalCharges()); }
    @Override public String toString() {
        StringBuilder text = new StringBuilder("HÓA ĐƠN KHÁCH SẠN\n===============================\n");
        text.append("Mã đặt: ").append(bookingId).append("\nKhách hàng: ").append(guestName)
            .append("\nĐiện thoại: ").append(phone).append("\nPhòng: ").append(room)
            .append("\nSố đêm đã đặt: ").append(nights).append("\nTiền phòng: ")
            .append(DisplayFormats.money(roomFee)).append("\n\nPhụ phí:\n");
        for (ServiceCharge charge : charges) text.append("- ").append(charge.getName()).append(": ")
                .append(DisplayFormats.money(charge.getAmount())).append('\n');
        if (charges.isEmpty()) text.append("- Không có\n");
        return text.append("\nTổng phụ phí: ").append(DisplayFormats.money(getTotalCharges()))
                .append("\nTỔNG THANH TOÁN: ").append(DisplayFormats.money(getTotal()))
                .append("\n\nTiền phòng tính theo số đêm đã đặt.\n").toString();
    }
}
