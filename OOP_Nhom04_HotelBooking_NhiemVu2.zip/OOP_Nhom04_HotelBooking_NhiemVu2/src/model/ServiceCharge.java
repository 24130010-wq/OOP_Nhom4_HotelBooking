package model;

import java.math.BigDecimal;
import java.util.Objects;

/** Phụ phí bất biến; dùng BigDecimal đồng bộ với nghiệp vụ thành viên 1. */
public final class ServiceCharge {
    private final String name;
    private final BigDecimal amount;
    public ServiceCharge(String name, BigDecimal amount) {
        if (name == null || name.isBlank()) throw new IllegalArgumentException("Tên phụ phí không được trống");
        this.amount = Objects.requireNonNull(amount);
        if (amount.signum() < 0) throw new IllegalArgumentException("Phụ phí không được âm");
        this.name = name.trim();
    }
    public String getName() { return name; }
    public BigDecimal getAmount() { return amount; }
}
