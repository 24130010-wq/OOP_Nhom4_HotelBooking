package vn.edu.ptit.oop.nhom04.integration;

import hotel.service.BookingService;
import javax.swing.*;
import java.util.Objects;

/** Giữ điểm nối cho thành viên 3/4. Không thay thế dialog thật bằng thao tác thanh toán giả. */
public final class PendingHotelActions implements HotelActions {
    private final BookingService service;
    public PendingHotelActions(BookingService service) { this.service = Objects.requireNonNull(service); }

    @Override public void openBooking(JFrame owner, RoomView room, Runnable afterChange) {
        if (!service.findRoom(room.getNumber()).isPresent()) {
            throw new IllegalArgumentException("Không tìm thấy phòng " + room.getNumber());
        }
        JOptionPane.showMessageDialog(owner,
                "Đã nối với phần nghiệp vụ của thành viên 1.\nPhòng đang chọn: " + room.getNumber()
                + ".\n\nĐang chờ BookingDialog của thành viên 3.\nChưa tạo đặt phòng mới.",
                "Đặt phòng — chờ tích hợp form", JOptionPane.INFORMATION_MESSAGE);
    }
    @Override public void openCheckout(JFrame owner, BookingView booking, Runnable afterChange) {
        boolean exists = service.getAllBookings().stream().anyMatch(b -> b.getBookingId().equals(booking.getId()));
        if (!exists) throw new IllegalArgumentException("Không tìm thấy đặt phòng");
        JOptionPane.showMessageDialog(owner,
                "Đặt phòng đang chọn: " + booking.getId() + "\nPhòng: " + booking.getRoomNumber()
                + ".\n\nĐang chờ InvoiceDialog và phụ phí của thành viên 3.\nChưa thanh toán hoặc trả phòng.",
                "Check-out — chờ tích hợp hóa đơn", JOptionPane.INFORMATION_MESSAGE);
    }
    @Override public void openCharts(JFrame owner) {
        JOptionPane.showMessageDialog(owner,
                "Đang chờ biểu đồ của thành viên 4.\nDữ liệu phòng và đặt phòng đã dùng chung BookingService.",
                "Biểu đồ — chờ tích hợp", JOptionPane.INFORMATION_MESSAGE);
    }
}
