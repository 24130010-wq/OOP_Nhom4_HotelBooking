
package vn.edu.ptit.oop.nhom04.statistics;

import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.BasicStroke;
import java.awt.Font;
import java.awt.RenderingHints;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Locale;

public class ChartHelper {

    // Tao bieu do cot cong suat phong
    public static JPanel createOccupancyChart(
            Map<String, Double> data) {

        return new JPanel() {

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);

                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(
                    RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON
                );

                int width = getWidth();
                int height = getHeight();

                g2.setColor(Color.WHITE);
                g2.fillRect(0, 0, width, height);

                g2.setColor(Color.BLACK);
                g2.setFont(new Font("Arial", Font.BOLD, 18));
                g2.drawString("CÔNG SUẤT PHÒNG THEO LOẠI", 25, 30);

                int left = 65;
                int bottom = height - 55;
                int chartHeight = height - 120;
                int chartWidth = width - 110;

                // Ve truc tung va truc hoanh
                g2.drawLine(left, 55, left, bottom);
                g2.drawLine(left, bottom, width - 30, bottom);

                // Cac vach chia truc tung
                for (int i = 0; i <= 100; i += 20) {
                    int y = bottom - (i * chartHeight / 100);

                    g2.setColor(Color.LIGHT_GRAY);
                    g2.drawLine(left, y, width - 30, y);

                    g2.setColor(Color.BLACK);
                    g2.drawString(i + "%", 25, y + 5);
                }

                if (data == null || data.isEmpty()) {
                    g2.drawString(
                        "Chưa có dữ liệu công suất",
                        left + 20,
                        bottom - 30
                    );
                    return;
                }

                int count = data.size();
                int slot = chartWidth / count;
                int barWidth = Math.min(65, slot / 2);
                int index = 0;

                Color[] colors = {
                    new Color(52, 152, 219),
                    new Color(46, 204, 113),
                    new Color(230, 126, 34)
                };

                for (Map.Entry<String, Double> entry
                        : data.entrySet()) {

                    double value = Math.max(
                        0,
                        Math.min(100, entry.getValue())
                    );

                    int barHeight =
                        (int) (value * chartHeight / 100);

                    int x = left + slot * index
                        + (slot - barWidth) / 2;

                    int y = bottom - barHeight;

                    g2.setColor(colors[index % colors.length]);
                    g2.fillRoundRect(
                        x, y, barWidth, barHeight, 10, 10
                    );

                    g2.setColor(Color.BLACK);
                    g2.drawString(
                        String.format("%.1f%%", value),
                        x - 2,
                        y - 8
                    );

                    g2.drawString(
                        entry.getKey(),
                        x - 5,
                        bottom + 22
                    );

                    index++;
                }

                g2.drawString(
                    "Loại phòng",
                    width / 2 - 30,
                    height - 10
                );
            }
        };
    }

    // Tao bieu do duong doanh thu 14 ngay
    public static JPanel createRevenueChart(
            Map<LocalDate, BigDecimal> data) {

        return new JPanel() {

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);

                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(
                    RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON
                );

                int width = getWidth();
                int height = getHeight();

                g2.setColor(Color.WHITE);
                g2.fillRect(0, 0, width, height);

                g2.setColor(Color.BLACK);
                g2.setFont(new Font("Arial", Font.BOLD, 18));
                g2.drawString(
                    "DOANH THU 14 NGÀY GẦN NHẤT",
                    25,
                    30
                );

                int left = 75;
                int right = width - 35;
                int top = 60;
                int bottom = height - 65;

                g2.drawLine(left, top, left, bottom);
                g2.drawLine(left, bottom, right, bottom);

                if (data == null || data.isEmpty()) {
                    g2.drawString(
                        "Chưa có dữ liệu doanh thu",
                        left + 20,
                        bottom - 30
                    );
                    return;
                }

                List<Map.Entry<LocalDate, BigDecimal>> entries =
                    new ArrayList<>(data.entrySet());

                BigDecimal max = BigDecimal.ZERO;

                for (Map.Entry<LocalDate, BigDecimal> entry
                        : entries) {

                    if (entry.getValue().compareTo(max) > 0) {
                        max = entry.getValue();
                    }
                }

                if (max.compareTo(BigDecimal.ZERO) == 0) {
                    max = BigDecimal.ONE;
                }

                NumberFormat money =
                    NumberFormat.getNumberInstance(
                        new Locale("vi", "VN")
                    );

                // Ve cac vach chia doanh thu
                for (int i = 0; i <= 4; i++) {
                    int y = bottom - i * (bottom - top) / 4;

                    g2.setColor(Color.LIGHT_GRAY);
                    g2.drawLine(left, y, right, y);

                    BigDecimal label = max.multiply(
                        BigDecimal.valueOf(i)
                    ).divide(BigDecimal.valueOf(4));

                    g2.setColor(Color.BLACK);
                    g2.drawString(
                        money.format(label),
                        5,
                        y + 5
                    );
                }

                int count = entries.size();
                int chartWidth = right - left;
                int chartHeight = bottom - top;

                int previousX = -1;
                int previousY = -1;

                g2.setColor(new Color(41, 128, 185));
                g2.setStroke(new BasicStroke(2.5f));

                for (int i = 0; i < count; i++) {

                    BigDecimal value = entries.get(i).getValue();

                    int x = left + i * chartWidth
                        / Math.max(1, count - 1);

                    int y = bottom - value.multiply(
                        BigDecimal.valueOf(chartHeight)
                    ).divide(max, 0,
                        java.math.RoundingMode.HALF_UP
                    ).intValue();

                    if (previousX != -1) {
                        g2.drawLine(
                            previousX,
                            previousY,
                            x,
                            y
                        );
                    }

                    g2.fillOval(x - 4, y - 4, 8, 8);

                    if (i % 2 == 0 || i == count - 1) {
                        String label = entries.get(i).getKey()
                            .format(
                                DateTimeFormatter.ofPattern("dd/MM")
                            );

                        g2.setColor(Color.BLACK);
                        g2.drawString(
                            label,
                            x - 15,
                            bottom + 20
                        );

                        g2.setColor(new Color(41, 128, 185));
                    }

                    previousX = x;
                    previousY = y;
                }

                g2.setColor(Color.BLACK);
                g2.drawString(
                    "Ngay",
                    width / 2,
                    height - 10
                );
            }
        };
    }
}
