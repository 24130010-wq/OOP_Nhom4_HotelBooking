
package vn.edu.ptit.oop.nhom04.statistics;

import hotel.model.Booking;
import hotel.model.Room;
import hotel.model.RoomStatus;
import hotel.service.BookingService;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class StatisticsService {

    private final BookingService bookingService;

    // Khoi tao StatisticsService
    public StatisticsService(BookingService bookingService) {
        if (bookingService == null) {
            throw new IllegalArgumentException(
                "BookingService khong duoc null"
            );
        }

        this.bookingService = bookingService;
    }

    // ==========================================
    // 1. THONG KE CONG SUAT PHONG THEO LOAI
    // ==========================================

    public Map<String, Double> getOccupancyRates(LocalDate date) {

        Map<String, Integer> totalRooms = new LinkedHashMap<>();
        Map<String, Integer> occupiedRooms = new LinkedHashMap<>();

        List<Room> rooms = bookingService.getAllRooms();
        List<Booking> bookings = bookingService.getAllBookings();

        // Dem tong so phong co the kinh doanh
        for (Room room : rooms) {

            if (room.getStatus() == RoomStatus.MAINTENANCE) {
                continue;
            }

            String type = room.getRoomType();

            totalRooms.put(
                type,
                totalRooms.getOrDefault(type, 0) + 1
            );
        }

        // Dem so phong dang co khach
        for (Booking booking : bookings) {

            boolean occupied =
                !date.isBefore(booking.getCheckInDate())
                && date.isBefore(
                    booking.getEffectiveCheckOutDate()
                );

            if (occupied) {

                String type = booking.getRoom().getRoomType();

                occupiedRooms.put(
                    type,
                    occupiedRooms.getOrDefault(type, 0) + 1
                );
            }
        }

        // Tinh phan tram cong suat
        Map<String, Double> result = new LinkedHashMap<>();

        for (String type : totalRooms.keySet()) {

            int total = totalRooms.get(type);
            int occupied = occupiedRooms.getOrDefault(type, 0);

            double rate = total == 0
                ? 0
                : occupied * 100.0 / total;

            result.put(type, rate);
        }

        return result;
    }

    // ==========================================
    // 2. THONG KE DOANH THU 14 NGAY GAN NHAT
    // ==========================================

    public Map<LocalDate, BigDecimal> getRevenueLast14Days() {

        Map<LocalDate, BigDecimal> revenue =
            new LinkedHashMap<>();

        LocalDate today = LocalDate.now();
        LocalDate startDate = today.minusDays(13);

        // Khoi tao doanh thu 14 ngay bang 0
        for (int i = 0; i < 14; i++) {

            LocalDate date = startDate.plusDays(i);

            revenue.put(date, BigDecimal.ZERO);
        }

        List<Booking> bookings =
            bookingService.getAllBookings();

        // Duyet tung don dat phong
        for (Booking booking : bookings) {

            LocalDate checkIn = booking.getCheckInDate();

            LocalDate checkOut =
                booking.getEffectiveCheckOutDate();

            BigDecimal price =
                booking.getRoom().getPricePerNight();

            // Tinh doanh thu theo tung dem
            LocalDate date = checkIn;

            while (date.isBefore(checkOut)) {

                if (revenue.containsKey(date)) {

                    BigDecimal oldRevenue = revenue.get(date);

                    revenue.put(
                        date,
                        oldRevenue.add(price)
                    );
                }

                date = date.plusDays(1);
            }
        }

        return revenue;
    }
}
