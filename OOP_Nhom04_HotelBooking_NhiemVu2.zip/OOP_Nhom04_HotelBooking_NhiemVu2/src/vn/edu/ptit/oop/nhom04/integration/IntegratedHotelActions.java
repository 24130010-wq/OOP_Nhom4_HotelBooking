
package vn.edu.ptit.oop.nhom04.integration;

import hotel.model.Booking;
import hotel.service.BookingService;
import hotel.service.CheckoutService;
import view.BookingDialog;
import view.InvoiceDialog;

import vn.edu.ptit.oop.nhom04.statistics.ChartWindow;

import javax.swing.*;
import java.util.Objects;

public final class IntegratedHotelActions implements HotelActions {

    private final BookingService service;
    private final CheckoutService checkoutService;

    public IntegratedHotelActions(BookingService service) {
        this.service = Objects.requireNonNull(service);
        checkoutService = new CheckoutService(service);
    }

    @Override
    public void openBooking(
            JFrame owner,
            RoomView room,
            Runnable afterChange) {

        new BookingDialog(
            owner,
            service,
            room.getNumber(),
            afterChange
        ).setVisible(true);
    }

    @Override
    public void openCheckout(
            JFrame owner,
            BookingView view,
            Runnable afterChange) {

        Booking booking = service.getAllBookings()
            .stream()
            .filter(b -> b.getBookingId().equals(view.getId()))
            .findFirst()
            .orElseThrow(() ->
                new IllegalArgumentException(
                    "Khong tim thay dat phong"
                )
            );

        InvoiceDialog dialog = new InvoiceDialog(
            owner,
            booking,
            checkoutService::confirm
        );

        dialog.setVisible(true);

        if (dialog.isConfirmed()) {
            afterChange.run();
        }
    }

    // Mo cua so bieu do
    @Override
    public void openCharts(JFrame owner) {

        ChartWindow chartWindow = new ChartWindow(service);

        chartWindow.setLocationRelativeTo(owner);
        chartWindow.setVisible(true);
    }

    public CheckoutService getCheckoutService() {
        return checkoutService;
    }
}
