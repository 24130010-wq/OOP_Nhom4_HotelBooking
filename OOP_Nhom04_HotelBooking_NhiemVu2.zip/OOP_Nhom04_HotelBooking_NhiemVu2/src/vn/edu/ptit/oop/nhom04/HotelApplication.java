package vn.edu.ptit.oop.nhom04;

import hotel.model.Guest;
import hotel.repository.InMemoryBookingRepository;
import hotel.service.BookingService;
import hotel.service.RoomNotAvailableException;
import java.time.LocalDate;

/** Khởi tạo đúng một service/repository dùng chung cho cả nhóm. */
public final class HotelApplication {
    private HotelApplication() { }

    public static BookingService createService(boolean withSampleBookings) {
        BookingService service = new BookingService(new InMemoryBookingRepository());
        if (withSampleBookings) seedSamples(service);
        return service;
    }

    private static void seedSamples(BookingService service) {
        LocalDate today = LocalDate.now();
        try {
            // Khách giả phục vụ chạy thử; đơn được tạo qua service thật, không phải dữ liệu bảng riêng.
            service.bookRoom("102", new Guest("DEMO01", "Khách mẫu An", "0900000001", ""), today, today.plusDays(3));
            service.bookRoom("204", new Guest("DEMO02", "Khách mẫu Bình", "0900000002", ""), today, today.plusDays(2));
            service.bookRoom("306", new Guest("DEMO03", "Khách mẫu Chi", "0900000003", ""), today, today.plusDays(4));
            service.bookRoom("103", new Guest("DEMO04", "Khách mẫu Dũng", "0900000004", ""), today.plusDays(4), today.plusDays(6));
            service.setRoomMaintenance("206");
            service.setRoomMaintenance("406");
        } catch (RoomNotAvailableException ex) {
            throw new IllegalStateException("Không khởi tạo được dữ liệu chạy thử", ex);
        }
    }
}
