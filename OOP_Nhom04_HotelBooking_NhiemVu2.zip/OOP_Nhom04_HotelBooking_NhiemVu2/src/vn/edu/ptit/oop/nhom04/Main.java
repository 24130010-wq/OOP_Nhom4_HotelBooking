package vn.edu.ptit.oop.nhom04;

import hotel.service.BookingService;
import vn.edu.ptit.oop.nhom04.integration.IntegratedHotelActions;
import vn.edu.ptit.oop.nhom04.integration.ServiceHotelGateway;
import vn.edu.ptit.oop.nhom04.ui.MainWindow;
import javax.swing.*;
import javax.swing.plaf.FontUIResource;
import java.awt.Font;

public final class Main {
    private Main() { }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            configureUi();
            boolean withSamples = !java.util.Arrays.asList(args).contains("--empty");
            BookingService service = HotelApplication.createService(withSamples);
            new MainWindow(new ServiceHotelGateway(service), new IntegratedHotelActions(service)).setVisible(true);
        });
    }

    public static void configureUi() {
        try { UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName()); }
        catch (ReflectiveOperationException | UnsupportedLookAndFeelException ex) { ex.printStackTrace(); }
        FontUIResource font = new FontUIResource(Font.SANS_SERIF, Font.PLAIN, 13);
        for (Object key : UIManager.getDefaults().keySet().toArray()) {
            if (UIManager.get(key) instanceof FontUIResource) UIManager.put(key, font);
        }
    }
}
