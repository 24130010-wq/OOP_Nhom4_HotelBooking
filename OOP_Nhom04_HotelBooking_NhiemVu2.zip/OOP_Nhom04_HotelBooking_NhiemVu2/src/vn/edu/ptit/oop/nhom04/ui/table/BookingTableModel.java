package vn.edu.ptit.oop.nhom04.ui.table;

import vn.edu.ptit.oop.nhom04.integration.BookingView;
import javax.swing.table.AbstractTableModel;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

/** Giữ kiểu số/ngày thật để JTable sắp xếp đúng, renderer chỉ định dạng hiển thị. */
public final class BookingTableModel extends AbstractTableModel {
    private final String[] columns = {"Mã đặt", "Phòng", "Khách hàng", "Ngày nhận", "Ngày trả", "Số đêm", "Tiền phòng", "Trạng thái"};
    private List<BookingView> rows = Collections.emptyList();

    public void setBookings(List<BookingView> bookings) {
        rows = Collections.unmodifiableList(new ArrayList<>(bookings));
        fireTableDataChanged();
    }
    public BookingView getBookingAt(int modelRow) { return rows.get(modelRow); }
    @Override public int getRowCount() { return rows.size(); }
    @Override public int getColumnCount() { return columns.length; }
    @Override public String getColumnName(int column) { return columns[column]; }
    @Override public boolean isCellEditable(int row, int column) { return false; }
    @Override public Class<?> getColumnClass(int column) {
        if (column == 3 || column == 4) return LocalDate.class;
        if (column == 5) return Long.class;
        if (column == 6) return BigDecimal.class;
        return String.class;
    }
    @Override public Object getValueAt(int row, int column) {
        BookingView b = rows.get(row);
        switch (column) {
            case 0: return b.getId();
            case 1: return b.getRoomNumber();
            case 2: return b.getGuestName();
            case 3: return b.getCheckIn();
            case 4: return b.getCheckOut();
            case 5: return b.getNights();
            case 6: return b.getRoomTotal();
            default: return b.isCheckedOut() ? "Đã trả phòng" : "Chưa trả phòng";
        }
    }
}
