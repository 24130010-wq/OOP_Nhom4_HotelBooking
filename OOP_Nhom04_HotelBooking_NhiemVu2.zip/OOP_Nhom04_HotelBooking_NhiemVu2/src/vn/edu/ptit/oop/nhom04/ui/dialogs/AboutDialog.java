package vn.edu.ptit.oop.nhom04.ui.dialogs;

import javax.swing.*;
import java.awt.*;

public final class AboutDialog extends JDialog {
    public AboutDialog(JFrame owner) {
        super(owner, "Giới thiệu ứng dụng", true);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        JPanel content = new JPanel(new BorderLayout(12, 16));
        content.setBorder(BorderFactory.createEmptyBorder(22, 24, 18, 24));
        content.add(new JLabel("<html><h2>Đặt phòng Khách sạn</h2>"
                + "Bài tập lớn Java OOP · Đề 4<br><br>"
                + "Đã ghép: nghiệp vụ, giao diện và form đặt phòng/hóa đơn.<br>"
                + "Dữ liệu trong bộ nhớ; mặc định tạo đặt phòng mẫu qua service.<br>"
                + "Đang chờ biểu đồ của thành viên 4.<br><br>"
                + "Nhóm: điền số nhóm thực tế · Thành viên: điền họ tên.</html>"), BorderLayout.CENTER);
        JButton close = new JButton("Đóng");
        close.addActionListener(e -> dispose());
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttons.add(close);
        content.add(buttons, BorderLayout.SOUTH);
        setContentPane(content);
        getRootPane().setDefaultButton(close);
        getRootPane().registerKeyboardAction(e -> dispose(), KeyStroke.getKeyStroke("ESCAPE"), JComponent.WHEN_IN_FOCUSED_WINDOW);
        pack();
        setResizable(false);
        setLocationRelativeTo(owner);
    }
}
