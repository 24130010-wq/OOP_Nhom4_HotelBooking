package vn.edu.ptit.oop.nhom04.demo;

import vn.edu.ptit.oop.nhom04.integration.*;
import javax.swing.*;

/** Thông báo rõ giới hạn bản giao diện, không giả vờ thao tác thành công. */
public final class DemoHotelActions implements HotelActions {
    @Override public void openBooking(JFrame owner, RoomView room, Runnable afterChange) {
        show(owner, "Đặt phòng " + room.getNumber(),
                "Đây là điểm nối BookingDialog của thành viên 3.\n"
                + "Truyền mã phòng " + room.getNumber() + " vào dialog.\n"
                + "Service của thành viên 1 kiểm tra lịch và lưu đặt phòng.\n"
                + "Sau khi lưu thành công, gọi afterChange.run().\n\n"
                + "Bản nhiệm vụ 2 chưa tạo đặt phòng mới.");
    }
    @Override public void openCheckout(JFrame owner, BookingView booking, Runnable afterChange) {
        show(owner, "Check-out " + booking.getId(),
                "Đây là điểm nối InvoiceDialog của thành viên 3.\n"
                + "Đặt phòng: " + booking.getId() + " / phòng " + booking.getRoomNumber() + ".\n"
                + "Sau khi xác nhận thanh toán, gọi afterChange.run().\n\n"
                + "Bản nhiệm vụ 2 chưa thanh toán hoặc thay đổi dữ liệu.");
    }
    @Override public void openCharts(JFrame owner) {
        show(owner, "Biểu đồ", "Đây là điểm nối ChartWindow của thành viên 4.\n"
                + "Cần BarChart công suất phòng và LineChart doanh thu 14 ngày.\n"
                + "Cửa sổ biểu đồ dùng DISPOSE_ON_CLOSE.\n\nBản này chưa chứa JFreeChart.");
    }
    private void show(JFrame owner, String title, String message) {
        JOptionPane.showMessageDialog(owner, message, title + " — điểm tích hợp", JOptionPane.INFORMATION_MESSAGE);
    }
}
