package vn.edu.ptit.oop.nhom04.ui.panels;

import vn.edu.ptit.oop.nhom04.integration.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.*;
import java.util.function.Consumer;

/** Sơ đồ 4 tầng × 6 phòng. Vẽ và hit-test dùng chung cách tính hình chữ nhật. */
public final class RoomMapPanel extends JPanel {
    public static final Color AVAILABLE_COLOR = new Color(220, 244, 232);
    public static final Color OCCUPIED_COLOR = new Color(255, 232, 211);
    public static final Color MAINTENANCE_COLOR = new Color(230, 233, 238);
    private List<RoomView> rooms = Collections.emptyList();
    private Consumer<RoomView> selectionListener = room -> { };
    private String selectedNumber;
    private int floorFilter;

    public RoomMapPanel() {
        setBackground(Color.WHITE);
        setPreferredSize(new Dimension(790, 350));
        setToolTipText("Chọn phòng để xem thông tin");
        getAccessibleContext().setAccessibleName("Sơ đồ 24 phòng khách sạn");
        addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                if (!SwingUtilities.isLeftMouseButton(e)) return;
                RoomView room = roomAt(e.getPoint());
                if (room != null) {
                    setSelectedRoom(room.getNumber());
                    selectionListener.accept(room);
                }
            }
        });
        addMouseMotionListener(new MouseMotionAdapter() {
            @Override public void mouseMoved(MouseEvent e) {
                RoomView room = roomAt(e.getPoint());
                setCursor(Cursor.getPredefinedCursor(room == null ? Cursor.DEFAULT_CURSOR : Cursor.HAND_CURSOR));
            }
        });
    }

    public void setRooms(List<RoomView> rooms) {
        List<RoomView> sorted = new ArrayList<>(rooms);
        sorted.sort(Comparator.comparingInt(RoomView::getFloor).thenComparing(RoomView::getNumber));
        this.rooms = Collections.unmodifiableList(sorted);
        repaint();
    }
    public void setOnRoomSelected(Consumer<RoomView> listener) {
        selectionListener = Objects.requireNonNull(listener);
    }
    public void setSelectedRoom(String number) { selectedNumber = number; repaint(); }
    public void setFloorFilter(int floor) { floorFilter = floor; repaint(); }

    public RoomView roomAt(Point point) {
        for (RoomView room : rooms) {
            Rectangle bounds = getRoomBounds(room.getNumber());
            if (bounds != null && bounds.contains(point)) return room;
        }
        return null;
    }

    /** Trả bản mới, dùng được cho hit-test và kiểm thử khi panel đổi kích thước. */
    public Rectangle getRoomBounds(String number) {
        int left = 65, gap = 10, right = 16, top = 15;
        int cardWidth = Math.max(1, (getWidth() - left - right - gap * 5) / 6);
        int rowHeight = Math.max(1, (getHeight() - top - 12) / 4);
        for (int floor = 1; floor <= 4; floor++) {
            int column = 0;
            for (RoomView room : rooms) {
                if (room.getFloor() != floor) continue;
                if (room.getNumber().equals(number)) {
                    if (floorFilter != 0 && floorFilter != floor) return null;
                    return new Rectangle(left + column * (cardWidth + gap), top + (floor - 1) * rowHeight,
                            cardWidth, Math.max(1, rowHeight - gap));
                }
                column++;
            }
        }
        return null;
    }

    @Override protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        Graphics2D g = (Graphics2D) graphics.create();
        try {
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int rowHeight = Math.max(1, (getHeight() - 27) / 4);
            g.setFont(getFont().deriveFont(Font.BOLD, 12f));
            for (int floor = 1; floor <= 4; floor++) {
                g.setColor(new Color(80, 92, 112));
                g.drawString("Tầng " + floor, 10, 15 + (floor - 1) * rowHeight + rowHeight / 2);
            }
            for (RoomView room : rooms) {
                Rectangle r = getRoomBounds(room.getNumber());
                if (r == null) continue;
                g.setColor(colorFor(room.getStatus()));
                g.fillRoundRect(r.x, r.y, r.width, r.height, 14, 14);
                g.setColor(room.getNumber().equals(selectedNumber) ? new Color(40, 88, 166) : new Color(207, 216, 226));
                g.setStroke(new BasicStroke(room.getNumber().equals(selectedNumber) ? 3f : 1f));
                g.drawRoundRect(r.x, r.y, r.width, r.height, 14, 14);
                g.setColor(new Color(30, 45, 65));
                g.setFont(getFont().deriveFont(Font.BOLD, 15f));
                centered(g, room.getNumber(), r, r.y + 22);
                g.setFont(getFont().deriveFont(Font.PLAIN, 11f));
                centered(g, room.getType(), r, r.y + 40);
                centered(g, room.getStatus().toString(), r, r.y + 57);
            }
        } finally { g.dispose(); }
    }

    private void centered(Graphics2D g, String text, Rectangle r, int baseline) {
        g.drawString(text, r.x + (r.width - g.getFontMetrics().stringWidth(text)) / 2, baseline);
    }
    public static Color colorFor(RoomStatus status) {
        switch (status) {
            case AVAILABLE: return AVAILABLE_COLOR;
            case OCCUPIED: return OCCUPIED_COLOR;
            default: return MAINTENANCE_COLOR;
        }
    }
}
