package vn.edu.ptit.oop.nhom04.integration;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Objects;

/** Dữ liệu hiển thị một dòng đặt phòng; tiền ở đây chỉ là tiền phòng, chưa gồm phụ phí. */
public final class BookingView {
    private final String id, roomNumber, guestName;
    private final LocalDate checkIn, checkOut;
    private final BigDecimal roomTotal;
    private final boolean checkedOut;

    public BookingView(String id, String roomNumber, String guestName, LocalDate checkIn,
                       LocalDate checkOut, BigDecimal roomTotal, boolean checkedOut) {
        this.id = Objects.requireNonNull(id);
        this.roomNumber = Objects.requireNonNull(roomNumber);
        this.guestName = Objects.requireNonNull(guestName);
        this.checkIn = Objects.requireNonNull(checkIn);
        this.checkOut = Objects.requireNonNull(checkOut);
        this.roomTotal = Objects.requireNonNull(roomTotal);
        if (!checkOut.isAfter(checkIn)) throw new IllegalArgumentException("Ngày trả phải sau ngày nhận");
        this.checkedOut = checkedOut;
    }
    public String getId() { return id; }
    public String getRoomNumber() { return roomNumber; }
    public String getGuestName() { return guestName; }
    public LocalDate getCheckIn() { return checkIn; }
    public LocalDate getCheckOut() { return checkOut; }
    public long getNights() { return ChronoUnit.DAYS.between(checkIn, checkOut); }
    public BigDecimal getRoomTotal() { return roomTotal; }
    public boolean isCheckedOut() { return checkedOut; }
}
