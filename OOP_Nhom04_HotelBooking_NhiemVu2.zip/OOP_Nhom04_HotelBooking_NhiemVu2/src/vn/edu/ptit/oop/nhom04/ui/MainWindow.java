package vn.edu.ptit.oop.nhom04.ui;

import vn.edu.ptit.oop.nhom04.common.BaseWindow;
import vn.edu.ptit.oop.nhom04.integration.*;
import vn.edu.ptit.oop.nhom04.ui.dialogs.AboutDialog;
import vn.edu.ptit.oop.nhom04.ui.panels.RoomMapPanel;
import vn.edu.ptit.oop.nhom04.ui.table.BookingTableModel;
import vn.edu.ptit.oop.nhom04.util.DisplayFormats;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.*;
import java.util.regex.Pattern;

public final class MainWindow extends BaseWindow {
    // KHÔNG khởi tạo tại khai báo: BaseWindow gọi initUI() trước constructor này.
    private HotelGateway gateway;
    private HotelActions actions;
    private List<RoomView> rooms;
    private RoomView selectedRoom;
    private RoomMapPanel roomMap;
    private BookingTableModel tableModel;
    private JTable bookingTable;
    private TableRowSorter<BookingTableModel> sorter;
    private JTextField searchField;
    private JTextArea detailText;
    private JLabel overviewLabel, selectionLabel;
    private JComboBox<String> floorCombo;
    private JButton bookingButton, checkoutButton;
    private JMenuItem bookingMenu, checkoutMenu;
    private boolean refreshing;

    public MainWindow(HotelGateway gateway, HotelActions actions) {
        super("Đề 4 · Đặt phòng Khách sạn · Nhiệm vụ 1 + 2 + 3", 1210, 850);
        this.gateway = Objects.requireNonNull(gateway);
        this.actions = Objects.requireNonNull(actions);
        setMinimumSize(new Dimension(1100, 800));
        refreshData();
    }

    @Override protected void initUI() {
        rooms = Collections.emptyList();
        roomMap = new RoomMapPanel();
        roomMap.setOnRoomSelected(this::selectRoom);
        tableModel = new BookingTableModel();
        bookingTable = new JTable(tableModel);
        bookingTable.setName("bookingTable");
        bookingTable.setRowHeight(29);
        bookingTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        bookingTable.setFillsViewportHeight(true);
        bookingTable.getTableHeader().setReorderingAllowed(false);
        sorter = new TableRowSorter<>(tableModel);
        bookingTable.setRowSorter(sorter);
        configureTable();
        bookingTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && !refreshing) {
                BookingView booking = selectedBooking();
                if (booking != null) findRoom(booking.getRoomNumber()).ifPresent(this::selectRoom);
                updateActions();
            }
        });
        overviewLabel = new JLabel();
        overviewLabel.setFont(overviewLabel.getFont().deriveFont(Font.BOLD, 15f));
        selectionLabel = new JLabel("Chưa chọn phòng");
        detailText = new JTextArea();
        detailText.setEditable(false);
        detailText.setLineWrap(true);
        detailText.setWrapStyleWord(true);
        detailText.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 13));
        detailText.setBackground(new Color(246, 248, 252));
        detailText.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        detailText.setText("Chọn một phòng trên sơ đồ hoặc một dòng đặt phòng để xem chi tiết.");

        JPanel mapArea = new JPanel(new BorderLayout(8, 8));
        mapArea.setBorder(BorderFactory.createTitledBorder("Sơ đồ phòng · trạng thái hôm nay"));
        floorCombo = new JComboBox<>(new String[]{"Tất cả tầng", "Tầng 1", "Tầng 2", "Tầng 3", "Tầng 4"});
        floorCombo.setName("floorCombo");
        floorCombo.addActionListener(e -> {
            roomMap.setFloorFilter(floorCombo.getSelectedIndex());
            if (selectedRoom != null && floorCombo.getSelectedIndex() != 0
                    && selectedRoom.getFloor() != floorCombo.getSelectedIndex()) clearRoomSelection();
        });
        JPanel mapHeader = new JPanel(new BorderLayout());
        mapHeader.add(new JLabel(" 4 tầng · 6 phòng / tầng"), BorderLayout.WEST);
        mapHeader.add(floorCombo, BorderLayout.EAST);
        mapArea.add(mapHeader, BorderLayout.NORTH);
        mapArea.add(new JScrollPane(roomMap), BorderLayout.CENTER);
        mapArea.add(createLegend(), BorderLayout.SOUTH);

        JPanel details = new JPanel(new BorderLayout(5, 5));
        details.setBorder(BorderFactory.createTitledBorder("Thông tin phòng"));
        details.setPreferredSize(new Dimension(255, 350));
        details.add(selectionLabel, BorderLayout.NORTH);
        details.add(new JScrollPane(detailText), BorderLayout.CENTER);
        JButton detailBooking = new JButton("Đặt phòng đang chọn");
        detailBooking.setName("detailBookingButton");
        detailBooking.addActionListener(e -> requestBooking());
        details.add(detailBooking, BorderLayout.SOUTH);
        JSplitPane mapSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, mapArea, details);
        mapSplit.setResizeWeight(0.78);
        mapSplit.setDividerLocation(865);

        JPanel top = new JPanel(new BorderLayout(8, 10));
        top.add(overviewLabel, BorderLayout.NORTH);
        top.add(mapSplit, BorderLayout.CENTER);
        JPanel bookings = createBookingsPanel();
        JSplitPane verticalSplit = new JSplitPane(JSplitPane.VERTICAL_SPLIT, top, bookings);
        verticalSplit.setResizeWeight(0.67);
        verticalSplit.setDividerLocation(460);
        top.setMinimumSize(new Dimension(900, 425));
        bookings.setMinimumSize(new Dimension(900, 150));
        JPanel center = new JPanel(new BorderLayout(8, 8));
        center.setBorder(BorderFactory.createEmptyBorder(10, 12, 10, 12));
        center.add(new JLabel("ĐẶT PHÒNG KHÁCH SẠN · Đặt phòng / hóa đơn đã hoạt động · Dữ liệu trong bộ nhớ · Biểu đồ chờ tích hợp"), BorderLayout.NORTH);
        center.add(verticalSplit, BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);
        initActions();
        updateActions();
    }

    private JPanel createLegend() {
        JPanel legend = new JPanel(new FlowLayout(FlowLayout.LEFT, 14, 6));
        for (RoomStatus status : RoomStatus.values()) {
            JLabel label = new JLabel("  " + status + "  ");
            label.setOpaque(true);
            label.setBackground(RoomMapPanel.colorFor(status));
            legend.add(label);
        }
        legend.add(new JLabel("Viền xanh: phòng đang chọn"));
        return legend;
    }

    private JPanel createBookingsPanel() {
        JPanel panel = new JPanel(new BorderLayout(6, 6));
        panel.setBorder(BorderFactory.createTitledBorder("Danh sách đặt phòng · click tiêu đề cột để sắp xếp"));
        searchField = new JTextField(25);
        searchField.setName("searchField");
        searchField.setToolTipText("Tìm mã đặt, số phòng hoặc tên khách; không phân biệt hoa thường");
        searchField.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { filter(); }
            public void removeUpdate(DocumentEvent e) { filter(); }
            public void changedUpdate(DocumentEvent e) { filter(); }
        });
        JPanel search = new JPanel(new FlowLayout(FlowLayout.LEFT));
        search.add(new JLabel("Tìm đặt phòng:")); search.add(searchField);
        JButton clear = new JButton("Xóa tìm kiếm");
        clear.addActionListener(e -> searchField.setText(""));
        search.add(clear);
        panel.add(search, BorderLayout.NORTH);
        panel.add(new JScrollPane(bookingTable), BorderLayout.CENTER);
        return panel;
    }

    private void filter() {
        String text = searchField.getText().trim();
        sorter.setRowFilter(text.isEmpty() ? null : RowFilter.regexFilter("(?iu)" + Pattern.quote(text), 0, 1, 2));
        updateActions();
    }

    private void configureTable() {
        DefaultTableCellRenderer dateRenderer = new DefaultTableCellRenderer() {
            @Override protected void setValue(Object value) {
                setText(value == null ? "" : DisplayFormats.date((LocalDate) value));
            }
        };
        bookingTable.setDefaultRenderer(LocalDate.class, dateRenderer);
        DefaultTableCellRenderer moneyRenderer = new DefaultTableCellRenderer() {
            @Override protected void setValue(Object value) {
                setText(value == null ? "" : DisplayFormats.money((BigDecimal) value));
            }
        };
        moneyRenderer.setHorizontalAlignment(SwingConstants.RIGHT);
        bookingTable.setDefaultRenderer(BigDecimal.class, moneyRenderer);
        int[] widths = {85, 65, 190, 110, 110, 65, 165, 140};
        for (int column = 0; column < widths.length; column++) {
            bookingTable.getColumnModel().getColumn(column).setPreferredWidth(widths[column]);
        }
    }

    private void initActions() {
        bookingButton = addToolButton("/resources/icons/add.png", "Đặt phòng (Ctrl+N)", e -> requestBooking());
        bookingButton.setText("Đặt phòng"); bookingButton.setName("bookingButton");
        checkoutButton = addToolButton("/resources/icons/checkout.png", "Check-out dòng đặt phòng đang chọn (Ctrl+O)", e -> requestCheckout());
        checkoutButton.setText("Check-out"); checkoutButton.setName("checkoutButton");
        toolBar.addSeparator();
        JButton charts = addToolButton("/resources/icons/chart.png", "Xem biểu đồ (Ctrl+B)", e -> requestCharts());
        charts.setText("Biểu đồ");
        JButton refresh = addToolButton("/resources/icons/refresh.png", "Nạp lại dữ liệu (F5)", e -> refreshData());
        refresh.setText("Làm mới");
        JButton about = addToolButton("/resources/icons/about.png", "Giới thiệu (F1)", e -> showAbout());
        about.setText("Giới thiệu");
        bookingMenu = menuItem("Đặt phòng...", "control N", e -> requestBooking());
        checkoutMenu = menuItem("Check-out...", "control O", e -> requestCheckout());
        fileMenu.insert(bookingMenu, 0); fileMenu.insert(checkoutMenu, 1); fileMenu.insertSeparator(2);
        viewMenu.add(menuItem("Làm mới dữ liệu", "F5", e -> refreshData()));
        viewMenu.add(menuItem("Biểu đồ...", "control B", e -> requestCharts()));
        JMenuItem aboutMenu = helpMenu.getItem(0);
        aboutMenu.setText("Giới thiệu...");
        aboutMenu.setAccelerator(KeyStroke.getKeyStroke("F1"));
    }

    private JMenuItem menuItem(String label, String shortcut, ActionListener action) {
        JMenuItem item = new JMenuItem(label);
        item.setAccelerator(KeyStroke.getKeyStroke(shortcut));
        item.addActionListener(action);
        return item;
    }

    /** Sau khi dialog lưu/thanh toán thành công, gọi hàm này trên EDT. */
    public void refreshData() {
        if (gateway == null) return; // initUI chạy trước khi gateway được truyền vào.
        try {
            List<RoomView> newRooms = new ArrayList<>(gateway.getRooms());
            List<BookingView> newBookings = new ArrayList<>(gateway.getBookings());
            String keepRoom = selectedRoom == null ? null : selectedRoom.getNumber();
            BookingView previousBooking = selectedBooking();
            refreshing = true;
            try {
                rooms = Collections.unmodifiableList(newRooms);
                roomMap.setRooms(rooms);
                bookingTable.clearSelection();
                tableModel.setBookings(newBookings);
                clearRoomSelection();
                if (keepRoom != null) findRoom(keepRoom).ifPresent(this::selectRoom);
                if (previousBooking != null) {
                    for (int row = 0; row < tableModel.getRowCount(); row++) {
                        if (tableModel.getBookingAt(row).getId().equals(previousBooking.getId())) {
                            int viewRow = bookingTable.convertRowIndexToView(row);
                            if (viewRow >= 0) bookingTable.setRowSelectionInterval(viewRow, viewRow);
                            break;
                        }
                    }
                }
            } finally { refreshing = false; }
            long free = rooms.stream().filter(r -> r.getStatus() == RoomStatus.AVAILABLE).count();
            long occupied = rooms.stream().filter(r -> r.getStatus() == RoomStatus.OCCUPIED).count();
            long maintenance = rooms.size() - free - occupied;
            overviewLabel.setText("HÔM NAY · " + DisplayFormats.date(LocalDate.now()) + "     |     "
                    + rooms.size() + " phòng     ·     " + free + " trống     ·     " + occupied + " đang ở     ·     " + maintenance + " bảo trì");
            setStatus("Đã nạp " + rooms.size() + " phòng, " + newBookings.size() + " đặt phòng. Chọn phòng để xem chi tiết.");
            updateActions();
        } catch (RuntimeException ex) { reportError(ex); }
    }

    private Optional<RoomView> findRoom(String number) {
        return rooms.stream().filter(r -> r.getNumber().equals(number)).findFirst();
    }
    private void clearRoomSelection() {
        selectedRoom = null;
        roomMap.setSelectedRoom(null);
        selectionLabel.setText("Chưa chọn phòng");
        detailText.setText("Chọn một phòng trên sơ đồ hoặc một dòng đặt phòng để xem chi tiết.");
        updateActions();
    }
    private void selectRoom(RoomView room) {
        selectedRoom = room;
        if (floorCombo.getSelectedIndex() != 0 && floorCombo.getSelectedIndex() != room.getFloor()) floorCombo.setSelectedIndex(0);
        roomMap.setSelectedRoom(room.getNumber());
        selectionLabel.setText("Phòng " + room.getNumber() + " · Tầng " + room.getFloor());
        detailText.setText("Loại phòng: " + room.getType() + "\n\nGiá / đêm: "
                + DisplayFormats.money(room.getPricePerNight()) + "\n\nTrạng thái hôm nay: " + room.getStatus()
                + "\n\nTiện nghi: " + room.getAmenities()
                + "\n\nLưu ý: trạng thái hôm nay không xác định phòng còn trống trong khoảng ngày muốn đặt. Service phải kiểm tra lịch.");
        detailText.setCaretPosition(0);
        setStatus("Đã chọn phòng " + room.getNumber() + " · " + room.getType() + " · " + room.getStatus());
        updateActions();
    }

    private BookingView selectedBooking() {
        int viewRow = bookingTable.getSelectedRow();
        if (viewRow < 0) return null;
        return tableModel.getBookingAt(bookingTable.convertRowIndexToModel(viewRow));
    }
    private boolean canCheckout(BookingView booking) {
        return booking != null && !booking.isCheckedOut() && !booking.getCheckIn().isAfter(LocalDate.now());
    }
    private void updateActions() {
        boolean canBook = selectedRoom != null && selectedRoom.getStatus() != RoomStatus.MAINTENANCE;
        if (bookingButton != null) bookingButton.setEnabled(canBook);
        if (bookingMenu != null) bookingMenu.setEnabled(canBook);
        boolean canOut = canCheckout(selectedBooking());
        if (checkoutButton != null) checkoutButton.setEnabled(canOut);
        if (checkoutMenu != null) checkoutMenu.setEnabled(canOut);
    }

    private void requestBooking() {
        if (selectedRoom == null) { info("Hãy chọn một phòng trên sơ đồ trước."); return; }
        if (selectedRoom.getStatus() == RoomStatus.MAINTENANCE) { info("Phòng đang bảo trì. Hãy chọn phòng khác."); return; }
        try { actions.openBooking(this, selectedRoom, this::refreshData); }
        catch (RuntimeException ex) { reportError(ex); }
    }
    private void requestCheckout() {
        BookingView booking = selectedBooking();
        if (!canCheckout(booking)) { info("Hãy chọn một đặt phòng đã đến ngày nhận và chưa trả trong bảng."); return; }
        try { actions.openCheckout(this, booking, this::refreshData); }
        catch (RuntimeException ex) { reportError(ex); }
    }
    private void requestCharts() {
        try { actions.openCharts(this); }
        catch (RuntimeException ex) { reportError(ex); }
    }
    private void info(String message) { JOptionPane.showMessageDialog(this, message, "Thông báo", JOptionPane.INFORMATION_MESSAGE); }
    private void reportError(RuntimeException ex) {
        ex.printStackTrace();
        setStatus("Không thực hiện được thao tác.");
        JOptionPane.showMessageDialog(this, "Không thực hiện được thao tác: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
    }
    @Override protected void showAbout() { new AboutDialog(this).setVisible(true); }
}
