package vn.edu.ptit.oop.nhom04.integration;

import hotel.model.Booking;
import hotel.model.BookingStatus;
import hotel.model.Room;
import hotel.service.BookingService;
import java.time.Clock;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

/** Nối model hotel.* của thành viên 1 vào GUI mà không tạo bản sao nghiệp vụ khác. */
public final class ServiceHotelGateway implements HotelGateway {
    private final BookingService service;
    private final Clock clock;

    public ServiceHotelGateway(BookingService service) {
        this(service, Clock.systemDefaultZone());
    }
    public ServiceHotelGateway(BookingService service, Clock clock) {
        this.service = Objects.requireNonNull(service);
        this.clock = Objects.requireNonNull(clock);
    }

    @Override public List<RoomView> getRooms() {
        LocalDate today = LocalDate.now(clock);
        List<Booking> bookings = service.getAllBookings();
        return service.getAllRooms().stream().map(room -> new RoomView(
                room.getRoomNumber(), room.getFloor(), room.getRoomType(), room.getPricePerNight(),
                room.getAmenities(), displayStatus(room, bookings, today)))
                .collect(Collectors.toUnmodifiableList());
    }

    private RoomStatus displayStatus(Room room, List<Booking> bookings, LocalDate today) {
        // Service gốc không tự gán OCCUPIED. GUI tính từ lịch, không sửa trạng thái model khi vẽ.
        if (room.getStatus() == hotel.model.RoomStatus.MAINTENANCE) return RoomStatus.MAINTENANCE;
        boolean occupied = bookings.stream().anyMatch(booking ->
                booking.getRoomNumber().equals(room.getRoomNumber())
                && booking.getStatus() != BookingStatus.CHECKED_OUT
                && !today.isBefore(booking.getCheckInDate())
                && today.isBefore(booking.getCheckOutDate()));
        return occupied ? RoomStatus.OCCUPIED : RoomStatus.AVAILABLE;
    }

    @Override public List<BookingView> getBookings() {
        return service.getAllBookings().stream().map(booking -> new BookingView(
                booking.getBookingId(), booking.getRoomNumber(), booking.getGuest().getFullName(),
                booking.getCheckInDate(), booking.getCheckOutDate(), booking.getRoomTotal(),
                booking.getStatus() == BookingStatus.CHECKED_OUT))
                .collect(Collectors.toUnmodifiableList());
    }
}
