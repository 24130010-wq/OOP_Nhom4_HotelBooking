
package vn.edu.ptit.oop.nhom04.statistics;

import hotel.service.BookingService;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;

public class ChartWindow extends JFrame {

    private final StatisticsService statisticsService;

    private JPanel occupancyPanel;
    private JPanel revenuePanel;

    public ChartWindow(BookingService bookingService) {

        statisticsService = new StatisticsService(bookingService);

        setTitle("Thống kế công suất phòng và doanh thu");
        setSize(950, 650);
        setLocationRelativeTo(null);

        // Dong cua so bieu do khong dong chuong trinh chinh
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        setLayout(new BorderLayout(10, 10));

        // Tieu de cua so
        JLabel title = new JLabel(
            "THỐNG KÊ KHÁCH SẠN",
            SwingConstants.CENTER
        );

        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setBorder(
            BorderFactory.createEmptyBorder(15, 10, 15, 10)
        );

        add(title, BorderLayout.NORTH);

        // Tao hai bieu do
        occupancyPanel = new JPanel(new BorderLayout());
        revenuePanel = new JPanel(new BorderLayout());

        // Tao tab hien thi
        JTabbedPane tabs = new JTabbedPane();

        tabs.addTab("Công suất phòng", occupancyPanel);
        tabs.addTab("Doanh thu 14 ngày", revenuePanel);

        add(tabs, BorderLayout.CENTER);

        // Nut cap nhat du lieu
        JButton refreshButton = new JButton("Cập nhật biểu đồ");

        refreshButton.addActionListener(e -> refreshCharts());

        JPanel bottomPanel = new JPanel();
        bottomPanel.add(refreshButton);

        add(bottomPanel, BorderLayout.SOUTH);

        // Hien thi du lieu lan dau
        refreshCharts();
    }

    // Cap nhat ca hai bieu do
    public void refreshCharts() {

        occupancyPanel.removeAll();
        revenuePanel.removeAll();

        // Lay du lieu cong suat hom nay
        occupancyPanel.add(
            ChartHelper.createOccupancyChart(
                statisticsService.getOccupancyRates(LocalDate.now())
            ),
            BorderLayout.CENTER
        );

        // Lay du lieu doanh thu 14 ngay
        revenuePanel.add(
            ChartHelper.createRevenueChart(
                statisticsService.getRevenueLast14Days()
            ),
            BorderLayout.CENTER
        );

        occupancyPanel.revalidate();
        occupancyPanel.repaint();

        revenuePanel.revalidate();
        revenuePanel.repaint();
    }
}
