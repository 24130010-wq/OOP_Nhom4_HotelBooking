package vn.edu.ptit.oop.nhom04.demo;

import vn.edu.ptit.oop.nhom04.integration.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

/** Chỉ dùng để chạy thử nhiệm vụ 2. Không đặt phòng hoặc thanh toán thật. */
public final class DemoHotelGateway implements HotelGateway {
    private final List<RoomView> rooms = new ArrayList<>();
    private final List<BookingView> bookings = new ArrayList<>();

    public DemoHotelGateway() {
        LocalDate today = LocalDate.now();
        for (int floor = 1; floor <= 4; floor++) {
            for (int position = 1; position <= 6; position++) {
                String number = String.valueOf(floor * 100 + position);
                String type = position <= 2 ? "Standard" : position <= 4 ? "Deluxe" : "Suite";
                BigDecimal price = BigDecimal.valueOf(position <= 2 ? 500000 : position <= 4 ? 850000 : 1500000);
                RoomStatus status = position == 6 && floor % 2 == 0 ? RoomStatus.MAINTENANCE
                        : position == 2 ? RoomStatus.OCCUPIED : RoomStatus.AVAILABLE;
                rooms.add(new RoomView(number, floor, type, price,
                        "Điều hòa, Wi-Fi, TV" + (position >= 3 ? ", minibar" : "")
                                + (position >= 5 ? ", phòng khách" : ""), status));
                if (status == RoomStatus.OCCUPIED) {
                    bookings.add(new BookingView("DP00" + floor, number,
                            new String[]{"Nguyễn Minh Anh", "Trần Hoàng Nam", "Lê Thu Hà", "Phạm Gia Bảo"}[floor - 1],
                            today.minusDays(1), today.plusDays(2), price.multiply(BigDecimal.valueOf(3)), false));
                }
            }
        }
        bookings.add(new BookingView("DP005", "103", "Võ Ngọc Mai", today.plusDays(4),
                today.plusDays(6), BigDecimal.valueOf(1700000), false));
        bookings.add(new BookingView("DP006", "301", "Đặng Quốc Huy", today.minusDays(5),
                today.minusDays(3), BigDecimal.valueOf(1000000), true));
    }
    @Override public List<RoomView> getRooms() { return Collections.unmodifiableList(rooms); }
    @Override public List<BookingView> getBookings() { return Collections.unmodifiableList(bookings); }
}
