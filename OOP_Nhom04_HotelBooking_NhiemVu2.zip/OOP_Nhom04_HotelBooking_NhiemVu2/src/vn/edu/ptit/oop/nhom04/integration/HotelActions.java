package vn.edu.ptit.oop.nhom04.integration;

import javax.swing.JFrame;

/** Điểm nối dialog của bạn 3 và biểu đồ của bạn 4. */
public interface HotelActions {
    void openBooking(JFrame owner, RoomView room, Runnable afterChange);
    void openCheckout(JFrame owner, BookingView booking, Runnable afterChange);
    void openCharts(JFrame owner);
}
