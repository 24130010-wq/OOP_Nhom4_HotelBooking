package vn.edu.ptit.oop.nhom04.integration;

public enum RoomStatus {
    AVAILABLE("Trống"), OCCUPIED("Đang ở"), MAINTENANCE("Bảo trì");
    private final String label;
    RoomStatus(String label) { this.label = label; }
    @Override public String toString() { return label; }
}
