package vn.edu.ptit.oop.nhom04.integration;

import java.math.BigDecimal;
import java.util.Objects;

/** Bản chụp dữ liệu chỉ đọc cho GUI, không thay thế lớp Room nghiệp vụ của bạn 1. */
public final class RoomView {
    private final String number, type, amenities;
    private final int floor;
    private final BigDecimal pricePerNight;
    private final RoomStatus status;

    public RoomView(String number, int floor, String type, BigDecimal pricePerNight,
                    String amenities, RoomStatus status) {
        if (floor < 1 || floor > 4) throw new IllegalArgumentException("Tầng phải từ 1 đến 4");
        this.number = Objects.requireNonNull(number);
        this.type = Objects.requireNonNull(type);
        this.amenities = Objects.requireNonNull(amenities);
        this.pricePerNight = Objects.requireNonNull(pricePerNight);
        if (pricePerNight.signum() < 0) throw new IllegalArgumentException("Giá phòng không âm");
        this.status = Objects.requireNonNull(status);
        this.floor = floor;
    }
    public String getNumber() { return number; }
    public int getFloor() { return floor; }
    public String getType() { return type; }
    public BigDecimal getPricePerNight() { return pricePerNight; }
    public String getAmenities() { return amenities; }
    public RoomStatus getStatus() { return status; }
}
