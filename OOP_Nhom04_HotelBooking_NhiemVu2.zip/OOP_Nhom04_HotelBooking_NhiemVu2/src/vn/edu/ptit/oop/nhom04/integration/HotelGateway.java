package vn.edu.ptit.oop.nhom04.integration;

import java.util.List;

/** Bạn 1/4 cài đặt interface này để chuyển model thật thành dữ liệu GUI. Gọi trên EDT, không làm I/O lâu. */
public interface HotelGateway {
    List<RoomView> getRooms();
    List<BookingView> getBookings();
}
