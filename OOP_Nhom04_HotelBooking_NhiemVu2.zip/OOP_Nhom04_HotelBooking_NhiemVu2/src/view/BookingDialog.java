package view;

import hotel.model.*;
import hotel.service.*;
import vn.edu.ptit.oop.nhom04.util.DisplayFormats;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.math.BigDecimal;
import java.text.ParseException;
import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

/** Form từ bài gửi: giữ bố cục xanh navy/teal, nối danh sách và giá vào service dùng chung. */
public final class BookingDialog extends JDialog {
    private final BookingService service;
    private final Runnable afterChange;
    private final List<Room> rooms;
    private final JTextField txtName = new JTextField(), txtPhone = new JTextField();
    private final JComboBox<String> cboRoom = new JComboBox<>();
    private final JSpinner spCheckIn, spCheckOut;
    private final JLabel lblNights = new JLabel(), lblRoomFee = new JLabel(), lblError = new JLabel(" ");
    private Booking booked;

    public BookingDialog(Window owner, BookingService service, String selectedRoom, Runnable afterChange) {
        super(owner, "Đặt phòng khách sạn", ModalityType.APPLICATION_MODAL);
        this.service = Objects.requireNonNull(service);
        this.afterChange = Objects.requireNonNull(afterChange);
        rooms = service.getAllRooms();
        LocalDate today = LocalDate.now();
        spCheckIn = spinner(today, "checkInSpinner");
        spCheckOut = spinner(today.plusDays(1), "checkOutSpinner");
        for (Room room : rooms) cboRoom.addItem(room.getRoomNumber() + " - " + room.getRoomType()
                + " · " + DisplayFormats.money(room.getPricePerNight()) + "/đêm");
        for (int i = 0; i < rooms.size(); i++) if (rooms.get(i).getRoomNumber().equals(selectedRoom)) cboRoom.setSelectedIndex(i);
        initComponents();
        spCheckIn.addChangeListener(e -> { lblError.setText(" "); updateRoomFee(); });
        spCheckOut.addChangeListener(e -> { lblError.setText(" "); updateRoomFee(); });
        cboRoom.addActionListener(e -> { lblError.setText(" "); updateRoomFee(); });
        DocumentListener clearError = new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { lblError.setText(" "); }
            public void removeUpdate(DocumentEvent e) { lblError.setText(" "); }
            public void changedUpdate(DocumentEvent e) { lblError.setText(" "); }
        };
        txtName.getDocument().addDocumentListener(clearError);
        txtPhone.getDocument().addDocumentListener(clearError);
        updateRoomFee();
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(740, 650);
        setMinimumSize(new Dimension(700, 620));
        setLocationRelativeTo(owner);
    }

    private JSpinner spinner(LocalDate date, String name) {
        Date value = Date.from(date.atStartOfDay(ZoneId.systemDefault()).toInstant());
        JSpinner spinner = new JSpinner(new SpinnerDateModel(value, null, null, java.util.Calendar.DAY_OF_MONTH));
        spinner.setEditor(new JSpinner.DateEditor(spinner, "dd/MM/yyyy"));
        ((JSpinner.DateEditor) spinner.getEditor()).getFormat().setLenient(false);
        spinner.setName(name);
        return spinner;
    }

    private void initComponents() {
        Color navy = new Color(27, 45, 75), teal = new Color(0, 150, 136);
        JPanel main = new JPanel(new BorderLayout(10, 12));
        main.setBorder(new EmptyBorder(0, 0, 12, 0));
        JPanel header = new JPanel(new GridLayout(2, 1, 0, 6));
        header.setBackground(navy); header.setBorder(new EmptyBorder(20, 25, 20, 25));
        JLabel title = new JLabel("HOTEL BOOKING");
        title.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 25)); title.setForeground(Color.WHITE);
        JLabel subtitle = new JLabel("Thông tin đặt phòng"); subtitle.setForeground(Color.WHITE);
        header.add(title); header.add(subtitle); main.add(header, BorderLayout.NORTH);
        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(new EmptyBorder(8, 22, 8, 22));
        txtName.setName("guestNameField"); txtPhone.setName("phoneField"); cboRoom.setName("roomCombo");
        row(form, 0, "Họ và tên khách hàng", txtName);
        row(form, 1, "Số điện thoại (10 chữ số)", txtPhone);
        row(form, 2, "Phòng / giá mỗi đêm", cboRoom);
        row(form, 3, "Ngày nhận phòng", spCheckIn);
        row(form, 4, "Ngày trả phòng", spCheckOut);
        JPanel summary = new JPanel(new GridLayout(3, 1, 0, 10));
        summary.setBackground(new Color(235, 248, 246)); summary.setBorder(new EmptyBorder(12, 14, 12, 14));
        lblRoomFee.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 21)); lblRoomFee.setForeground(teal);
        lblRoomFee.setName("roomFeeLabel"); lblError.setName("bookingErrorLabel"); lblError.setForeground(new Color(175, 25, 25));
        summary.add(lblNights); summary.add(lblRoomFee); summary.add(lblError);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx=0; gbc.gridy=5; gbc.gridwidth=2; gbc.fill=GridBagConstraints.HORIZONTAL;
        gbc.weightx=1; gbc.insets=new Insets(12,0,0,0); form.add(summary,gbc);
        main.add(form, BorderLayout.CENTER);
        JButton save = new JButton("Đặt phòng"), close = new JButton("Đóng");
        save.setName("confirmBookingButton"); close.setName("cancelBookingButton");
        save.addActionListener(e -> bookRoom()); close.addActionListener(e -> dispose());
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT,12,0)); buttons.add(close); buttons.add(save);
        main.add(buttons,BorderLayout.SOUTH); setContentPane(main);
        getRootPane().setDefaultButton(save);
        getRootPane().registerKeyboardAction(e -> dispose(), KeyStroke.getKeyStroke("ESCAPE"), JComponent.WHEN_IN_FOCUSED_WINDOW);
    }
    private void row(JPanel panel, int y, String label, JComponent field) {
        GridBagConstraints g = new GridBagConstraints();
        g.gridy=y; g.gridx=0; g.anchor=GridBagConstraints.WEST; g.insets=new Insets(9,0,9,12);
        panel.add(new JLabel(label),g);
        g.gridx=1; g.weightx=1; g.fill=GridBagConstraints.HORIZONTAL; g.ipady=12;
        panel.add(field,g);
    }
    private LocalDate date(JSpinner spinner) {
        return ((Date)spinner.getValue()).toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }
    private void updateRoomFee() {
        int index=cboRoom.getSelectedIndex();
        long nights=ChronoUnit.DAYS.between(date(spCheckIn), date(spCheckOut));
        lblNights.setText(nights>0 ? "Số đêm lưu trú: "+nights : "Ngày trả phải sau ngày nhận");
        BigDecimal fee=index<0 || nights<=0 ? BigDecimal.ZERO : rooms.get(index).getPricePerNight().multiply(BigDecimal.valueOf(nights));
        lblRoomFee.setText(DisplayFormats.money(fee));
    }
    private void bookRoom() {
        try {
            spCheckIn.commitEdit(); spCheckOut.commitEdit();
            if (txtName.getText().isBlank()) throw new IllegalArgumentException("Vui lòng nhập họ tên khách hàng.");
            if (!txtPhone.getText().trim().matches("[0-9]{10}")) throw new IllegalArgumentException("Điện thoại phải gồm 10 chữ số.");
            if (cboRoom.getSelectedIndex()<0) throw new IllegalArgumentException("Vui lòng chọn phòng.");
            Guest guest=new Guest(UUID.randomUUID().toString(),txtName.getText().trim(),txtPhone.getText().trim(),"");
            booked=service.bookRoom(rooms.get(cboRoom.getSelectedIndex()).getRoomNumber(),guest,date(spCheckIn),date(spCheckOut));
        } catch (ParseException ex) {
            lblError.setText("Ngày không hợp lệ. Hãy nhập theo dd/MM/yyyy."); return;
        } catch (IllegalArgumentException | RoomNotAvailableException ex) {
            lblError.setText(ex.getMessage()); return;
        }
        dispose();
        afterChange.run();
    }
    public Booking getBooked() { return booked; }
}
