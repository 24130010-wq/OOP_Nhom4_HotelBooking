package view;

import hotel.model.Booking;
import model.Invoice;
import model.ServiceCharge;
import javax.swing.*;
import java.awt.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;

/** Xem trước hóa đơn không trả phòng. Chỉ nút Xác nhận mới gọi nghiệp vụ check-out. */
public final class InvoiceDialog extends JDialog {
    private final Booking booking;
    private final Consumer<Invoice> onConfirm;
    private final JCheckBox chkMinibar = new JCheckBox("Minibar - 150.000 VND");
    private final JCheckBox chkLaundry = new JCheckBox("Giặt ủi - 100.000 VND");
    private final JTextArea txtInvoice = new JTextArea(17, 48);
    private final JLabel error = new JLabel(" ");
    private boolean confirmed;

    public InvoiceDialog(Window owner, Booking booking, Consumer<Invoice> onConfirm) {
        super(owner,"Hóa đơn và check-out",ModalityType.APPLICATION_MODAL);
        this.booking=Objects.requireNonNull(booking); this.onConfirm=Objects.requireNonNull(onConfirm);
        JPanel content=new JPanel(new BorderLayout(10,10));
        content.setBorder(BorderFactory.createEmptyBorder(14,14,14,14));
        JPanel services=new JPanel(new GridLayout(0,1));
        services.setBorder(BorderFactory.createTitledBorder("Phụ phí dịch vụ"));
        chkMinibar.setName("minibarCheckbox"); chkLaundry.setName("laundryCheckbox");
        services.add(chkMinibar); services.add(chkLaundry); content.add(services,BorderLayout.NORTH);
        txtInvoice.setName("invoiceText"); txtInvoice.setEditable(false);
        txtInvoice.setFont(new Font(Font.MONOSPACED,Font.PLAIN,13));
        content.add(new JScrollPane(txtInvoice),BorderLayout.CENTER);
        JButton calculate=new JButton("Tính hóa đơn"), confirm=new JButton("Xác nhận thanh toán & trả phòng"), close=new JButton("Đóng");
        calculate.setName("calculateInvoiceButton"); confirm.setName("confirmCheckoutButton"); close.setName("cancelInvoiceButton");
        calculate.addActionListener(e -> showInvoice()); close.addActionListener(e -> dispose());
        confirm.addActionListener(e -> {
            if (confirmed) return;
            try { onConfirm.accept(currentInvoice()); }
            catch (RuntimeException ex) { error.setText(ex.getMessage()); return; }
            confirmed=true; dispose();
        });
        chkMinibar.addActionListener(e -> showInvoice()); chkLaundry.addActionListener(e -> showInvoice());
        JPanel bottom=new JPanel(new BorderLayout());
        error.setName("invoiceErrorLabel"); error.setForeground(new Color(175,25,25)); bottom.add(error,BorderLayout.NORTH);
        JPanel buttons=new JPanel(new FlowLayout(FlowLayout.RIGHT)); buttons.add(close); buttons.add(calculate); buttons.add(confirm);
        bottom.add(buttons,BorderLayout.SOUTH); content.add(bottom,BorderLayout.SOUTH); setContentPane(content);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE); setSize(780,570); setMinimumSize(new Dimension(740,520));
        setLocationRelativeTo(owner);
        getRootPane().registerKeyboardAction(e -> dispose(),KeyStroke.getKeyStroke("ESCAPE"),JComponent.WHEN_IN_FOCUSED_WINDOW);
        showInvoice();
    }
    private Invoice currentInvoice() {
        List<ServiceCharge> charges=new ArrayList<>();
        if (chkMinibar.isSelected()) charges.add(new ServiceCharge("Minibar",new BigDecimal("150000")));
        if (chkLaundry.isSelected()) charges.add(new ServiceCharge("Giặt ủi",new BigDecimal("100000")));
        return new Invoice(booking,charges);
    }
    private void showInvoice() { txtInvoice.setText(currentInvoice().toString()); txtInvoice.setCaretPosition(0); }
    public boolean isConfirmed() { return confirmed; }
}
