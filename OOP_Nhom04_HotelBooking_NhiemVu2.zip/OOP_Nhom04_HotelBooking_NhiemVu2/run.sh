#!/bin/sh
set -eu
cd "$(dirname "$0")"
sh build.sh
java -jar dist/HotelBooking-NhiemVu2.jar
