@echo off
setlocal
cd /d "%~dp0"
if not exist build\classes mkdir build\classes
if not exist dist mkdir dist
(for /r src %%f in (*.java) do @echo "%%f") > build\sources-windows.txt
javac --release 11 -encoding UTF-8 -d build\classes @build\sources-windows.txt
if errorlevel 1 goto fail
xcopy /e /i /y src\resources build\classes\resources >nul
if errorlevel 1 goto fail
jar cfe dist\HotelBooking-NhiemVu2.jar vn.edu.ptit.oop.nhom04.Main -C build\classes .
if errorlevel 1 goto fail
java -jar dist\HotelBooking-NhiemVu2.jar
if errorlevel 1 goto fail
exit /b 0
:fail
echo Khong chay duoc. Kiem tra da cai JDK 11 tro len va PATH.
pause
exit /b 1
