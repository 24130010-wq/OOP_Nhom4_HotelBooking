
import javax.swing.SwingUtilities;
import view.BookingDialog;

public class MainTest {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            BookingDialog dialog = new BookingDialog(null);
            dialog.setVisible(true);
        });
    }
}
