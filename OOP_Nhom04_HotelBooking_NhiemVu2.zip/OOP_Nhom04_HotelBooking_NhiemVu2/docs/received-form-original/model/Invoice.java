package model;

import java.util.ArrayList;
import java.util.List;

public class Invoice {
    private String guestName;
    private String phone;
    private String room;
    private int nights;
    private double roomFee;
    private List<ServiceCharge> charges = new ArrayList<>();

    public Invoice(String guestName, String phone, String room,
                   int nights, double roomFee) {
        this.guestName = guestName;
        this.phone = phone;
        this.room = room;
        this.nights = nights;
        this.roomFee = roomFee;
    }

    public void addCharge(ServiceCharge charge) {
        charges.add(charge);
    }

    public double getTotalCharges() {
        double total = 0;
        for (ServiceCharge charge : charges) {
            total += charge.getAmount();
        }
        return total;
    }

    public double getTotal() {
        return roomFee + getTotalCharges();
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append("========== HOA DON KHACH SAN ==========\n");
        sb.append("Khach hang: ").append(guestName).append("\n");
        sb.append("Dien thoai: ").append(phone).append("\n");
        sb.append("Phong: ").append(room).append("\n");
        sb.append("So dem: ").append(nights).append("\n");
        sb.append("Tien phong: ")
          .append(String.format("%,.0f VND", roomFee)).append("\n");

        sb.append("Phu phi:\n");
        for (ServiceCharge charge : charges) {
            sb.append("- ").append(charge.getName()).append(": ")
              .append(String.format("%,.0f VND", charge.getAmount()))
              .append("\n");
        }

        sb.append("Tong phu phi: ")
          .append(String.format("%,.0f VND", getTotalCharges())).append("\n");
        sb.append("TONG THANH TOAN: ")
          .append(String.format("%,.0f VND", getTotal())).append("\n");

        return sb.toString();
    }
}