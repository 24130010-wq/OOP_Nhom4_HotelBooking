
package view;

import model.Invoice;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import java.awt.*;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Date;

public class BookingDialog extends JDialog {

    private JTextField txtName;
    private JTextField txtPhone;
    private JComboBox<String> cboRoom;
    private JSpinner spCheckIn;
    private JSpinner spCheckOut;
    private JLabel lblNights;
    private JLabel lblRoomFee;

    private final Color navy = new Color(27, 45, 75);
    private final Color teal = new Color(0, 150, 136);
    private final Color background = new Color(245, 248, 252);
    private final Color textColor = new Color(55, 65, 81);

    private final int[] roomPrices = {
        300000, 500000, 700000, 900000,
        1200000, 1500000, 2000000, 3000000,
        350000, 600000, 1000000, 1800000, 2500000
    };

    public BookingDialog(Window owner) {
        super(owner, "Hotel Booking - Dat phong khach san",
                ModalityType.APPLICATION_MODAL);

        initComponents();

        setSize(720, 700);
        setMinimumSize(new Dimension(650, 650));
        setLocationRelativeTo(owner);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }

    private void initComponents() {
        JPanel main = new JPanel(new BorderLayout(0, 0));
        main.setBackground(background);

        // HEADER
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(navy);
        header.setBorder(new EmptyBorder(22, 28, 22, 28));

        JLabel title = new JLabel("HOTEL BOOKING");
        title.setFont(new Font("Arial", Font.BOLD, 25));
        title.setForeground(Color.WHITE);

        JLabel subtitle = new JLabel("HE THONG DAT PHONG KHACH SAN");
        subtitle.setFont(new Font("Arial", Font.PLAIN, 12));
        subtitle.setForeground(new Color(200, 215, 235));

        JPanel titlePanel = new JPanel();
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));
        titlePanel.setBackground(navy);
        titlePanel.add(title);
        titlePanel.add(Box.createVerticalStrut(6));
        titlePanel.add(subtitle);

        header.add(titlePanel, BorderLayout.WEST);

        // FORM
        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Color.WHITE);
        form.setBorder(new EmptyBorder(22, 25, 22, 25));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(9, 5, 9, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;

        JLabel section = new JLabel("THONG TIN DAT PHONG");
        section.setFont(new Font("Arial", Font.BOLD, 17));
        section.setForeground(navy);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        form.add(section, gbc);

        txtName = new JTextField();
        txtPhone = new JTextField();

        styleField(txtName);
        styleField(txtPhone);

        // Chi cho nhap toi da 10 chu so
        ((AbstractDocument) txtPhone.getDocument())
                .setDocumentFilter(new DocumentFilter() {
            @Override
            public void insertString(FilterBypass fb, int offset,
                                     String str, AttributeSet attr)
                    throws BadLocationException {
                if (str != null && str.matches("[0-9]+")
                        && fb.getDocument().getLength()
                        + str.length() <= 10) {
                    super.insertString(fb, offset, str, attr);
                }
            }

            @Override
            public void replace(FilterBypass fb, int offset, int length,
                                String str, AttributeSet attr)
                    throws BadLocationException {
                String old = fb.getDocument().getText(
                        0, fb.getDocument().getLength());

                String inserted = str == null ? "" : str;
                String updated = old.substring(0, offset)
                        + inserted
                        + old.substring(offset + length);

                if (updated.matches("[0-9]{0,10}")) {
                    super.replace(fb, offset, length, str, attr);
                }
            }
        });

        cboRoom = new JComboBox<>(new String[]{
            "101 - Standard",
            "102 - Superior",
            "103 - Deluxe",
            "104 - Premium",
            "105 - Executive",
            "106 - Suite",
            "107 - VIP",
            "108 - Presidential Suite",
            "109 - Economy",
            "110 - Business",
            "111 - Junior Suite",
            "112 - Family Suite",
            "113 - Royal Suite"
        });
        cboRoom.setSelectedIndex(0);
        styleCombo(cboRoom);

        Date today = new Date();
        Date tomorrow = new Date(
                today.getTime() + 24L * 60 * 60 * 1000);

        spCheckIn = new JSpinner(new SpinnerDateModel(
                today, null, null, java.util.Calendar.DAY_OF_MONTH));

        spCheckOut = new JSpinner(new SpinnerDateModel(
                tomorrow, null, null, java.util.Calendar.DAY_OF_MONTH));

        spCheckIn.setEditor(
                new JSpinner.DateEditor(spCheckIn, "dd/MM/yyyy"));
        spCheckOut.setEditor(
                new JSpinner.DateEditor(spCheckOut, "dd/MM/yyyy"));

        styleSpinner(spCheckIn);
        styleSpinner(spCheckOut);

        addFormRow(form, gbc, 1, "Ho va ten khach hang", txtName);
        addFormRow(form, gbc, 2, "So dien thoai (10 chu so)", txtPhone);
        addFormRow(form, gbc, 3, "Hang phong", cboRoom);
        addFormRow(form, gbc, 4, "Ngay nhan phong", spCheckIn);
        addFormRow(form, gbc, 5, "Ngay tra phong", spCheckOut);

        // SUMMARY
        JPanel summary = new JPanel(new GridLayout(2, 1, 0, 8));
        summary.setBackground(new Color(235, 248, 246));
        summary.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                        new Color(190, 230, 222)),
                new EmptyBorder(15, 18, 15, 18)));

        lblNights = new JLabel();
        lblNights.setFont(new Font("Arial", Font.BOLD, 15));
        lblNights.setForeground(navy);

        lblRoomFee = new JLabel();
        lblRoomFee.setFont(new Font("Arial", Font.BOLD, 23));
        lblRoomFee.setForeground(teal);

        summary.add(lblNights);
        summary.add(lblRoomFee);

        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(18, 5, 8, 5);
        form.add(summary, gbc);

        // BUTTONS
        JButton btnBook = new JButton("DAT PHONG");
        JButton btnClose = new JButton("DONG");

        styleButton(btnBook, teal, Color.WHITE);
        styleButton(btnClose, new Color(235, 239, 245), navy);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 15));
        buttons.setBackground(background);
        buttons.setBorder(new EmptyBorder(0, 20, 5, 20));
        buttons.add(btnClose);
        buttons.add(btnBook);

        main.add(header, BorderLayout.NORTH);
        main.add(form, BorderLayout.CENTER);
        main.add(buttons, BorderLayout.SOUTH);

        setContentPane(main);

        spCheckIn.addChangeListener(e -> updateRoomFee());
        spCheckOut.addChangeListener(e -> updateRoomFee());
        cboRoom.addActionListener(e -> updateRoomFee());

        btnBook.addActionListener(e -> bookRoom());
        btnClose.addActionListener(e -> dispose());

        updateRoomFee();
    }

    private void addFormRow(JPanel panel, GridBagConstraints gbc,
                            int row, String label, JComponent field) {
        JLabel lbl = new JLabel(label);
        lbl.setFont(new Font("Arial", Font.BOLD, 13));
        lbl.setForeground(textColor);

        gbc.gridy = row;
        gbc.gridx = 0;
        gbc.gridwidth = 1;
        gbc.weightx = 0.38;
        panel.add(lbl, gbc);

        gbc.gridx = 1;
        gbc.weightx = 0.62;
        panel.add(field, gbc);
    }

    private void styleField(JTextField field) {
        field.setFont(new Font("Arial", Font.PLAIN, 14));
        field.setPreferredSize(new Dimension(250, 38));
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                        new Color(210, 218, 230)),
                new EmptyBorder(7, 10, 7, 10)));
    }

    private void styleCombo(JComboBox<String> combo) {
        combo.setFont(new Font("Arial", Font.PLAIN, 14));
        combo.setPreferredSize(new Dimension(250, 38));
        combo.setBackground(Color.WHITE);
    }

    private void styleSpinner(JSpinner spinner) {
        spinner.setFont(new Font("Arial", Font.PLAIN, 14));
        spinner.setPreferredSize(new Dimension(250, 38));
        JComponent editor = spinner.getEditor();
        editor.setFont(new Font("Arial", Font.PLAIN, 14));
    }

    private void styleButton(JButton button, Color bg, Color fg) {
        button.setFont(new Font("Arial", Font.BOLD, 13));
        button.setForeground(fg);
        button.setBackground(bg);
        button.setFocusPainted(false);
        button.setBorder(new EmptyBorder(12, 22, 12, 22));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setOpaque(true);
    }

    private int calculateNights(Date checkIn, Date checkOut) {
        LocalDate start = checkIn.toInstant()
                .atZone(ZoneId.systemDefault()).toLocalDate();

        LocalDate end = checkOut.toInstant()
                .atZone(ZoneId.systemDefault()).toLocalDate();

        return (int) ChronoUnit.DAYS.between(start, end);
    }

    private void updateRoomFee() {
        Date checkIn = (Date) spCheckIn.getValue();
        Date checkOut = (Date) spCheckOut.getValue();

        int nights = calculateNights(checkIn, checkOut);
        int price = roomPrices[cboRoom.getSelectedIndex()];

        if (nights <= 0) {
            lblNights.setText("So dem: Ngay tra phai sau ngay nhan");
            lblRoomFee.setText("0 VND");
        } else {
            lblNights.setText("SO DEM LUU TRU: " + nights + " dem");
            lblRoomFee.setText(String.format("%,d VND",
                    (long) price * nights));
        }
    }

    private void bookRoom() {
        String name = txtName.getText().trim();
        String phone = txtPhone.getText().trim();

        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Vui long nhap ho va ten khach hang!");
            txtName.requestFocus();
            return;
        }

        if (!phone.matches("[0-9]{10}")) {
            JOptionPane.showMessageDialog(this,
                    "So dien thoai phai du 10 chu so!");
            txtPhone.requestFocus();
            return;
        }

        Date checkIn = (Date) spCheckIn.getValue();
        Date checkOut = (Date) spCheckOut.getValue();
        int nights = calculateNights(checkIn, checkOut);

        if (nights <= 0) {
            JOptionPane.showMessageDialog(this,
                    "Ngay tra phong phai sau ngay nhan phong!");
            return;
        }

        String room = (String) cboRoom.getSelectedItem();
        int price = roomPrices[cboRoom.getSelectedIndex()];
        int roomFee = (int) ((long) price * nights);

        Invoice invoice = new Invoice(
                name, phone, room, nights, roomFee);

        new InvoiceDialog(this, invoice).setVisible(true);
    }
}
