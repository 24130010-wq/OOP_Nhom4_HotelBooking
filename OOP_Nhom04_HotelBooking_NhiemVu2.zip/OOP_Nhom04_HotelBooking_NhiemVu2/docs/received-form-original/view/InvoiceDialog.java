
package view;

import model.Invoice;
import model.ServiceCharge;

import javax.swing.*;
import java.awt.*;
import java.text.NumberFormat;
import java.util.Locale;

public class InvoiceDialog extends JDialog {

    private Invoice invoice;
    private JCheckBox chkMinibar =
        new JCheckBox("Minibar - 150.000 VND");
    private JCheckBox chkLaundry =
        new JCheckBox("Giat ui - 100.000 VND");

    private JTextArea txtInvoice = new JTextArea(14, 35);
    private boolean generated = false;

    public InvoiceDialog(Dialog owner, Invoice invoice) {
        super(owner, "Hoa don thanh toan", true);
        this.invoice = invoice;

        setLayout(new BorderLayout(10, 10));

        JPanel services = new JPanel(new GridLayout(0, 1));
        services.setBorder(BorderFactory.createTitledBorder("Phu phi"));
        services.add(chkMinibar);
        services.add(chkLaundry);

        txtInvoice.setEditable(false);
        txtInvoice.setFont(new Font("Monospaced", Font.PLAIN, 13));

        JButton btnCalculate = new JButton("Tinh hoa don");
        JButton btnClose = new JButton("Dong");

        btnCalculate.addActionListener(e -> showInvoice());
        btnClose.addActionListener(e -> dispose());

        JPanel buttons = new JPanel();
        buttons.add(btnCalculate);
        buttons.add(btnClose);

        add(services, BorderLayout.NORTH);
        add(new JScrollPane(txtInvoice), BorderLayout.CENTER);
        add(buttons, BorderLayout.SOUTH);

        setSize(480, 400);
        setLocationRelativeTo(owner);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }

    private void showInvoice() {
        if (generated) {
            JOptionPane.showMessageDialog(this,
                "Hoa don da duoc tinh.");
            return;
        }

        if (chkMinibar.isSelected()) {
            invoice.addCharge(new ServiceCharge("Minibar", 150000));
        }

        if (chkLaundry.isSelected()) {
            invoice.addCharge(new ServiceCharge("Giat ui", 100000));
        }

        txtInvoice.setText(invoice.toString());
        generated = true;
    }
}
