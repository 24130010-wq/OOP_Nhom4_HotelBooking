/**
 * 
 */
/**
 * 
 */
module HotelBooking {
}