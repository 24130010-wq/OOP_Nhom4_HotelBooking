package hotel.repository;

import hotel.model.Booking;
import java.util.List;
import java.util.Optional;

public interface BookingRepository {

    void add(Booking booking);

    void update(Booking booking);

    Optional<Booking> findById(String bookingId);

    List<Booking> findAll();
}