package hotel.model;

import java.math.BigDecimal;

public class DeluxeRoom extends Room {

    public DeluxeRoom(String roomNumber, int floor) {
        super(roomNumber, floor, RoomStatus.AVAILABLE);
    }

    @Override
    public String getRoomType() {
        return "Deluxe";
    }

    @Override
    public BigDecimal getPricePerNight() {
        return new BigDecimal("800000");
    }
}