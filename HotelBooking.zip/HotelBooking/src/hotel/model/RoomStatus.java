package hotel.model;

public enum RoomStatus {
	 AVAILABLE,
	    OCCUPIED,
	    MAINTENANCE
}
