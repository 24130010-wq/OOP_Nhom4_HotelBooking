package hotel.model;

public enum BookingStatus {
	CONFIRMED,
    CHECKED_OUT
}
