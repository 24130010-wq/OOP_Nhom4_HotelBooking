package hotel.model;

import java.math.BigDecimal;

public class SuiteRoom extends Room {

    public SuiteRoom(String roomNumber, int floor) {
        super(roomNumber, floor, RoomStatus.AVAILABLE);
    }

    @Override
    public String getRoomType() {
        return "Suite";
    }

    @Override
    public BigDecimal getPricePerNight() {
        return new BigDecimal("1500000");
    }
}