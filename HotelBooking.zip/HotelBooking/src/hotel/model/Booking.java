package hotel.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Objects;

public class Booking {
    private final String bookingId;
    private final Guest guest;
    private final Room room;
    private final LocalDate checkInDate;
    private final LocalDate checkOutDate;
    private final long numberOfNights;
    private final BigDecimal roomTotal;

    private BookingStatus status;
    private LocalDate actualCheckOutDate;

    public Booking(String bookingId, Guest guest, Room room,
                   LocalDate checkInDate, LocalDate checkOutDate) {

        if (bookingId == null || bookingId.isBlank()) {
            throw new IllegalArgumentException(
                    "Ma dat phong khong duoc de trong.");
        }

        this.guest = Objects.requireNonNull(
                guest, "Khach hang khong duoc null.");

        this.room = Objects.requireNonNull(
                room, "Phong khong duoc null.");

        this.checkInDate = Objects.requireNonNull(
                checkInDate, "Ngay nhan phong khong duoc null.");

        this.checkOutDate = Objects.requireNonNull(
                checkOutDate, "Ngay tra phong khong duoc null.");

        if (!checkOutDate.isAfter(checkInDate)) {
            throw new IllegalArgumentException(
                    "Ngay tra phong phai sau ngay nhan phong.");
        }

        this.bookingId = bookingId;
        this.numberOfNights =
                ChronoUnit.DAYS.between(checkInDate, checkOutDate);

        this.roomTotal = room.getPricePerNight()
                .multiply(BigDecimal.valueOf(numberOfNights));

        this.status = BookingStatus.CONFIRMED;
        this.actualCheckOutDate = null;
    }

    public String getBookingId() {
        return bookingId;
    }

    public Guest getGuest() {
        return guest;
    }

    public Room getRoom() {
        return room;
    }

    public String getRoomNumber() {
        return room.getRoomNumber();
    }

    public LocalDate getCheckInDate() {
        return checkInDate;
    }

    public LocalDate getCheckOutDate() {
        return checkOutDate;
    }

    public long getNumberOfNights() {
        return numberOfNights;
    }

    public BigDecimal getRoomTotal() {
        return roomTotal;
    }

    public BookingStatus getStatus() {
        return status;
    }

    public LocalDate getActualCheckOutDate() {
        return actualCheckOutDate;
    }

    // Ngay ket thuc thuc te dung de kiem tra lich phong
    public LocalDate getEffectiveCheckOutDate() {
        if (actualCheckOutDate != null) {
            return actualCheckOutDate;
        }

        return checkOutDate;
    }

    // Tra phong theo ngay thuc te
    public void markCheckedOut(LocalDate actualDate) {
        Objects.requireNonNull(actualDate,
                "Ngay tra thuc te khong duoc null.");

        if (status == BookingStatus.CHECKED_OUT) {
            throw new IllegalStateException(
                    "Don dat phong da duoc tra truoc do.");
        }

        if (actualDate.isBefore(checkInDate)) {
            throw new IllegalStateException(
                    "Khong the tra phong truoc ngay nhan phong.");
        }

        actualCheckOutDate = actualDate;
        status = BookingStatus.CHECKED_OUT;
    }

    // Giu lai phuong thuc cu neu thanh vien khac dang su dung
    public void markCheckedOut() {
        markCheckedOut(LocalDate.now());
    }
}