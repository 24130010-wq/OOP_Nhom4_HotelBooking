package hotel.model;

import java.util.Objects;
import java.util.regex.Pattern;

public class Guest {
    private final String guestId;
    private final String fullName;
    private final String phone;
    private final String email;

    public Guest(String guestId, String fullName,
                 String phone, String email) {

        if (guestId == null || guestId.isBlank()) {
            throw new IllegalArgumentException("Ma khach hang khong duoc trong.");
        }

        if (fullName == null || fullName.isBlank()) {
            throw new IllegalArgumentException("Ho ten khong duoc trong.");
        }

        if (phone == null || !Pattern.matches("[0-9+() .-]{8,20}", phone)) {
            throw new IllegalArgumentException("So dien thoai khong hop le.");
        }

        if (email != null && !email.isBlank()
                && !Pattern.matches("^[\\w.+-]+@[\\w.-]+\\.[A-Za-z]{2,}$", email)) {
            throw new IllegalArgumentException("Email khong hop le.");
        }

        this.guestId = guestId.trim();
        this.fullName = fullName.trim();
        this.phone = phone.trim();
        this.email = email == null ? "" : email.trim();
    }

    public String getGuestId() {
        return guestId;
    }

    public String getFullName() {
        return fullName;
    }

    public String getPhone() {
        return phone;
    }

    public String getEmail() {
        return email;
    }
}