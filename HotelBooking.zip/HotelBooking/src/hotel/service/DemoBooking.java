
package hotel.service;

import hotel.model.*;
import hotel.repository.BookingRepository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class DemoBooking {

    // Repository tam thoi de kiem thu, khong can database
    static class DemoRepository implements BookingRepository {

        private final List<Booking> bookings = new ArrayList<>();

        @Override
        public void add(Booking booking) {
            bookings.add(booking);
        }

        @Override
        public void update(Booking booking) {
            // Booking duoc cap nhat truc tiep trong bo nho
        }

        @Override
        public Optional<Booking> findById(String bookingId) {
            return bookings.stream()
                    .filter(b -> b.getBookingId().equals(bookingId))
                    .findFirst();
        }

        @Override
        public List<Booking> findAll() {
            return new ArrayList<>(bookings);
        }
    }

    // Interface cho phep bai kiem thu nem checked exception
    @FunctionalInterface
    interface TestAction {
        void run() throws Exception;
    }

    private static int passed = 0;
    private static int failed = 0;

    // Chay mot bai kiem thu
    private static void check(String name, TestAction test) {
        try {
            test.run();
            passed++;
            System.out.println("[PASS] " + name);
        } catch (Throwable e) {
            failed++;
            System.out.println("[FAIL] " + name
                    + " | " + e.getClass().getSimpleName()
                    + ": " + e.getMessage());
        }
    }

    // Kiem tra mot hanh dong co nem dung loai loi mong doi khong
    private static void expectError(
            Class<? extends Throwable> expected,
            TestAction action) {

        try {
            action.run();
        } catch (Throwable e) {
            if (expected.isInstance(e)) {
                return;
            }

            throw new AssertionError(
                    "Mong doi " + expected.getSimpleName()
                    + " nhung nhan duoc "
                    + e.getClass().getSimpleName(), e);
        }

        throw new AssertionError(
                "Khong co loi nao duoc nem ra.");
    }

    private static Guest createGuest(String id) {
        return new Guest(
                id,
                "Nguyen Van " + id,
                "0912345678",
                id.toLowerCase() + "@example.com"
        );
    }

    public static void main(String[] args) {

        DemoRepository repository = new DemoRepository();
        BookingService service = new BookingService(repository);

        LocalDate today = LocalDate.now();

        passed = 0;
        failed = 0;

        System.out.println("===== KIEM THU NGHIEP VU DAT PHONG =====");

        // TEST 1: Khoi tao 24 phong
        check("Khoi tao dung 24 phong", () -> {
            if (service.getAllRooms().size() != 24) {
                throw new AssertionError("So phong khong bang 24");
            }
        });

        // TEST 2: Gia Standard
        check("Gia Standard la 500000/dem", () -> {
            Room room = service.findRoom("101").orElseThrow();

            if (room.getPricePerNight().intValueExact() != 500000) {
                throw new AssertionError("Sai gia Standard");
            }
        });

        // TEST 3: Gia Deluxe
        check("Gia Deluxe la 800000/dem", () -> {
            Room room = service.findRoom("104").orElseThrow();

            if (room.getPricePerNight().intValueExact() != 800000) {
                throw new AssertionError("Sai gia Deluxe");
            }
        });

        // TEST 4: Gia Suite
        check("Gia Suite la 1500000/dem", () -> {
            Room room = service.findRoom("106").orElseThrow();

            if (room.getPricePerNight().intValueExact() != 1500000) {
                throw new AssertionError("Sai gia Suite");
            }
        });

        // TEST 5: Dat phong hop le, 3 dem
        check("Dat phong Standard thanh cong", () -> {
            Booking booking = service.bookRoom(
                    "101",
                    createGuest("G001"),
                    today.plusDays(1),
                    today.plusDays(4)
            );

            if (booking.getNumberOfNights() != 3) {
                throw new AssertionError("Sai so dem");
            }

            if (booking.getRoomTotal().intValueExact() != 1500000) {
                throw new AssertionError("Sai tong tien");
            }
        });

        // TEST 6: Trung lich phong 101
        check("Tu choi dat trung lich", () -> {
            expectError(RoomNotAvailableException.class, () ->
                    service.bookRoom(
                            "101",
                            createGuest("G002"),
                            today.plusDays(2),
                            today.plusDays(5)
                    )
            );
        });

        // TEST 7: Khach moi den dung ngay khach truoc tra
        check("Cho phep dat ngay tiep theo", () -> {
            service.bookRoom(
                    "101",
                    createGuest("G003"),
                    today.plusDays(4),
                    today.plusDays(6)
            );
        });

        // TEST 8: Phong khong ton tai
        check("Tu choi ma phong khong ton tai", () -> {
            expectError(IllegalArgumentException.class, () ->
                    service.bookRoom(
                            "999",
                            createGuest("G004"),
                            today.plusDays(1),
                            today.plusDays(2)
                    )
            );
        });

        // TEST 9: Khach hang null
        check("Tu choi khi thieu khach hang", () -> {
            expectError(IllegalArgumentException.class, () ->
                    service.bookRoom(
                            "102",
                            null,
                            today.plusDays(1),
                            today.plusDays(2)
                    )
            );
        });

        // TEST 10: Ngay nhan trong qua khu
        check("Tu choi ngay nhan trong qua khu", () -> {
            expectError(IllegalArgumentException.class, () ->
                    service.bookRoom(
                            "102",
                            createGuest("G005"),
                            today.minusDays(1),
                            today.plusDays(1)
                    )
            );
        });

        // TEST 11: Ngay tra bang ngay nhan
        check("Tu choi ngay nhan bang ngay tra", () -> {
            expectError(IllegalArgumentException.class, () ->
                    service.bookRoom(
                            "102",
                            createGuest("G006"),
                            today.plusDays(1),
                            today.plusDays(1)
                    )
            );
        });

        // TEST 12: Ngay tra truoc ngay nhan
        check("Tu choi ngay tra truoc ngay nhan", () -> {
            expectError(IllegalArgumentException.class, () ->
                    service.bookRoom(
                            "102",
                            createGuest("G007"),
                            today.plusDays(3),
                            today.plusDays(2)
                    )
            );
        });

        // TEST 13: Phong bao tri
        check("Tu choi dat phong bao tri", () -> {
            service.setRoomMaintenance("102");

            expectError(RoomNotAvailableException.class, () ->
                    service.bookRoom(
                            "102",
                            createGuest("G008"),
                            today.plusDays(1),
                            today.plusDays(2)
                    )
            );
        });

        // TEST 14: Tra phong truoc ngay nhan
        check("Tu choi tra phong qua som", () -> {
            Booking booking = service.bookRoom(
                    "103",
                    createGuest("G009"),
                    today.plusDays(2),
                    today.plusDays(5)
            );

            expectError(IllegalStateException.class, () ->
                    service.checkOut(
                            booking.getBookingId(),
                            today.plusDays(1)
                    )
            );
        });

        // TEST 15: Tra som, sau do dat lai phong
        check("Cho dat lai sau khi khach tra som", () -> {
            Booking oldBooking = service.bookRoom(
                    "104",
                    createGuest("G010"),
                    today,
                    today.plusDays(5)
            );

            service.checkOut(
                    oldBooking.getBookingId(),
                    today.plusDays(1)
            );

            service.bookRoom(
                    "104",
                    createGuest("G011"),
                    today.plusDays(1),
                    today.plusDays(3)
            );
        });

        // TEST 16: Ma dat phong khong ton tai
        check("Tu choi ma dat phong khong ton tai", () -> {
            expectError(IllegalArgumentException.class, () ->
                    service.checkOut("KHONG_CO_DON")
            );
        });

        // TEST 17: Tra phong hai lan
        check("Tu choi tra phong hai lan", () -> {
            Booking booking = service.bookRoom(
                    "105",
                    createGuest("G012"),
                    today,
                    today.plusDays(2)
            );

            service.checkOut(
                    booking.getBookingId(), today);

            expectError(IllegalStateException.class, () ->
                    service.checkOut(
                            booking.getBookingId(), today)
            );
        });

     // TEST 18: Khong xoa trang thai bao tri khi tra phong
        check("Giu nguyen trang thai bao tri", () -> {
            Room room = service.findRoom("106").orElseThrow();

            // Buoc 1: Dat phong khi phong chua bao tri
            Booking booking = service.bookRoom(
                    "106",
                    createGuest("G013"),
                    today,
                    today.plusDays(2)
            );

            // Buoc 2: Chuyen phong sang trang thai bao tri
            room.setStatus(RoomStatus.MAINTENANCE);

            // Buoc 3: Tra phong
            service.checkOut(
                    booking.getBookingId(), today
            );

            // Buoc 4: Xac nhan phong van dang bao tri
            if (room.getStatus() != RoomStatus.MAINTENANCE) {
                throw new AssertionError(
                        "Trang thai bao tri bi thay doi");
            }
        });

        // Tong ket
        System.out.println();
        System.out.println("===== KET QUA KIEM THU =====");
        System.out.println("Thanh cong: " + passed);
        System.out.println("That bai: " + failed);
        System.out.println("Tong so test: " + (passed + failed));
    }
}
