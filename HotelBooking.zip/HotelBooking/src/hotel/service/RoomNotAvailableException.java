package hotel.service;

public class RoomNotAvailableException extends Exception {

    /**
	 * 
	 */
	private static final long serialVersionUID = 220412916914926317L;

	public RoomNotAvailableException(String message) {
        super(message);
    }
}