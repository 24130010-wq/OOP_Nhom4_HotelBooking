package hotel.service;

import hotel.model.*;
import hotel.repository.BookingRepository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public class BookingService {

    private final List<Room> rooms = new ArrayList<>();
    private final BookingRepository repository;

    public BookingService(BookingRepository repository) {
        if (repository == null) {
            throw new IllegalArgumentException(
                    "Repository khong duoc null.");
        }

        this.repository = repository;
        initializeRooms();
    }

    // Tao 24 phong: 4 tang, moi tang 6 phong
    private void initializeRooms() {
        for (int floor = 1; floor <= 4; floor++) {
            for (int number = 1; number <= 6; number++) {

                String roomNumber =
                        String.valueOf(floor * 100 + number);

                Room room;

                if (number <= 3) {
                    room = new StandardRoom(roomNumber, floor);
                } else if (number <= 5) {
                    room = new DeluxeRoom(roomNumber, floor);
                } else {
                    room = new SuiteRoom(roomNumber, floor);
                }

                rooms.add(room);
            }
        }
    }

    public List<Room> getAllRooms() {
        return List.copyOf(rooms);
    }

    public Optional<Room> findRoom(String roomNumber) {
        if (roomNumber == null || roomNumber.isBlank()) {
            return Optional.empty();
        }

        return rooms.stream()
                .filter(room ->
                        room.getRoomNumber().equals(roomNumber.trim()))
                .findFirst();
    }

    public List<Booking> getAllBookings() {
        return List.copyOf(repository.findAll());
    }

    // Kiem tra hai khoang thoi gian co bi trung nhau khong
    private boolean isOverlapping(
            LocalDate start1, LocalDate end1,
            LocalDate start2, LocalDate end2) {

        return start1.isBefore(end2)
                && start2.isBefore(end1);
    }

    // Dat phong
    public Booking bookRoom(
            String roomNumber,
            Guest guest,
            LocalDate checkIn,
            LocalDate checkOut)
            throws RoomNotAvailableException {

        // 1. Kiem tra khach hang
        if (guest == null) {
            throw new IllegalArgumentException(
                    "Vui long nhap thong tin khach hang.");
        }

        // 2. Kiem tra ngay
        if (checkIn == null || checkOut == null) {
            throw new IllegalArgumentException(
                    "Ngay nhan va ngay tra khong duoc de trong.");
        }

        // 3. Khong cho dat ngay trong qua khu
        if (checkIn.isBefore(LocalDate.now())) {
            throw new IllegalArgumentException(
                    "Ngay nhan phong khong duoc o trong qua khu.");
        }

        // 4. Ngay tra phai sau ngay nhan
        if (!checkOut.isAfter(checkIn)) {
            throw new IllegalArgumentException(
                    "Ngay tra phong phai sau ngay nhan phong.");
        }

        // 5. Tim phong
        Room room = findRoom(roomNumber)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Khong tim thay phong: " + roomNumber));

        // 6. Phong bao tri khong duoc dat
        if (room.getStatus() == RoomStatus.MAINTENANCE) {
            throw new RoomNotAvailableException(
                    "Phong " + roomNumber + " dang bao tri.");
        }

        // 7. Kiem tra lich dat cua cung mot phong
        for (Booking existing : repository.findAll()) {

            if (!existing.getRoomNumber().equals(roomNumber.trim())) {
                continue;
            }

            // Don da tra thi dung ngay tra thuc te
            LocalDate existingEnd =
                    existing.getEffectiveCheckOutDate();

            boolean overlaps = isOverlapping(
                    checkIn,
                    checkOut,
                    existing.getCheckInDate(),
                    existingEnd
            );

            if (overlaps) {
                throw new RoomNotAvailableException(
                        "Phong " + roomNumber
                        + " da co lich dat trong khoang ngay nay.");
            }
        }

        // 8. Tao va luu don dat phong
        String bookingId = UUID.randomUUID().toString();

        Booking booking = new Booking(
                bookingId,
                guest,
                room,
                checkIn,
                checkOut
        );

        repository.add(booking);

        return booking;
    }

    // Tra phong vao ngay hien tai
    public Booking checkOut(String bookingId) {
        return checkOut(bookingId, LocalDate.now());
    }

    // Phien ban co ngay tra de de kiem thu
    public Booking checkOut(
            String bookingId, LocalDate actualDate) {

        if (bookingId == null || bookingId.isBlank()) {
            throw new IllegalArgumentException(
                    "Ma dat phong khong duoc de trong.");
        }

        if (actualDate == null) {
            throw new IllegalArgumentException(
                    "Ngay tra thuc te khong duoc null.");
        }

        Booking booking = repository.findById(bookingId)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Khong tim thay don dat phong."));

        // Khong tra phong truoc ngay nhan
        if (actualDate.isBefore(booking.getCheckInDate())) {
            throw new IllegalStateException(
                    "Khong the tra phong truoc ngay nhan phong.");
        }

        // Cap nhat trang thai va ngay tra thuc te
        booking.markCheckedOut(actualDate);
        repository.update(booking);

        // Khong vo tinh xoa trang thai bao tri
        if (booking.getRoom().getStatus()
                != RoomStatus.MAINTENANCE) {
            booking.getRoom().setStatus(RoomStatus.AVAILABLE);
        }

        return booking;
    }

    // Danh dau phong dang bao tri
    public void setRoomMaintenance(String roomNumber) {
        Room room = findRoom(roomNumber)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Khong tim thay phong: " + roomNumber));

        room.setStatus(RoomStatus.MAINTENANCE);
    }

    // Dua phong tro lai trang thai san sang
    public void setRoomAvailable(String roomNumber) {
        Room room = findRoom(roomNumber)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Khong tim thay phong: " + roomNumber));

        room.setStatus(RoomStatus.AVAILABLE);
    }
}